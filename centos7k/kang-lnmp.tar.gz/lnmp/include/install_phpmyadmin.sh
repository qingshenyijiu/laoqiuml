#!/bin/bash

# 安装phpmyadmin
cd /root/
curl -O https://raw.githubusercontent.com/qingshenyijiu/laoqiuml/master/centos7k/phpMyAdmin-4.6.2-all-languages.tar.gz
tar -zxvf phpMyAdmin-4.6.2-all-languages.tar.gz -C /home/wwwroot/default/
rm -f phpMyAdmin-4.6.2-all-languages.tar.gz 
