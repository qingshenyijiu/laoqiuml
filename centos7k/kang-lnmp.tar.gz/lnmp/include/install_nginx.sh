#!/bin/bash

# 安装ngixn
rpm -Uvh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm
yum -y install nginx
mv /usr/share/nginx /home/wwwroot
cp -r ${cur_dir}/conf/default.conf /etc/nginx/conf.d/default.conf
systemctl enable nginx.service
systemctl start nginx.service
