<?php
include "api.inc.php";
$shop=$DB->get_row("SELECT shopUrl FROM  `ov`.`auth_config`");
//$shop = $DB->fetch($shop);
print_r($shop);
echo $shop['0'];
//header('location: http://'.$shop[`shopUrl`].'');

?>