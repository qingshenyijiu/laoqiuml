<?php
/*数据库配置*/
$host = "localhost"; //MYSQL主机
$port = 3306; //MYSQL主机
$user = "root"; //MYSQL用户
$pwd = "kangmlsql"; //MYSQL密码
$dbname = "ov"; //数据库名
// $adminuser="admin";//管理员用户名,已废弃
// $adminpass="1";//管理员密码,已废弃
$conf_rate="0.05";//推荐人返现折扣率,取值范围（0~1）
?>