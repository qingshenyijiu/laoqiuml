<?php
return array (
  'ver' => '',
  'release' => '2016.07.08',
  'vername' => '（傲慢与偏见）作品 ',
);
?>