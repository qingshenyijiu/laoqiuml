<?php
//购买说明
$info_buy = '激活码购买地址：<a target="blank" href="http://kangml.com/">http://kangml.com/</a>';

//联系QQ
$info_qq = '123456';

$twice_free = 0;