﻿﻿<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"/>
    <meta name="MobileOptimized" content="320"/>
    <meta name="author" content="<?php echo $author; ?>"/>
    <meta name="robots" content="none"/>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/mui.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/default.js"></script>
    <title><?php echo $title; ?></title>
    <link type="image/x-icon" rel="icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link type="image/x-icon" rel="shortcut icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/mui.min.css" rel="stylesheet"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/default.css" rel="stylesheet"/>
    <style type="text/css">
        html, body {
            height: 100%;
            overflow: hidden;
            background: #FFFFFF;
        }

        .mui-content {
            padding: 10px;
            background: #FFFFFF;
        }

        .mui-table-view:after {
            height: 0;
        }

        .mui-table-view-cell:after {
            left: 1px;
        }

        .mui-input-group .mui-input-row::after {
            left: 0;
        }

        .mui-input-group::before,
        .mui-input-group::after {
            height: 0;
        }

        .mui-btn {
            padding: 5px;
        }
    </style>
</head>

<body>
<noscript class="error">
    很遗憾，由于你的浏览器不支持或禁用了JavaScript，导致无法获得正常体验。
</noscript><header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left" href="javascript:history.back();"></a>

    <h1 class="mui-title"><?php echo $title; ?></h1>
</header>
<div class="mui-content">
    <form class="mui-input-group">
        <h5>名称：</h5>

        <div class="mui-input-row">
            <input type="text" id="category_name" name="category_name" maxlength="50" placeholder="50字以内"
                   class="mui-input-clear mui-input"/>
        </div>
        <h5>排序：</h5>

        <div class="mui-input-row">
            <input type="number" id="category_sortby" name="category_sortby" value="0"
                   class="mui-input-clear mui-input"/>
        </div>
    </form>
    <div class="mui-content-padded">
        <button class="mui-btn mui-btn-block mui-btn-primary" onclick="categoryAdd()">添加</button>
    </div>
    <div class="loader hide"></div>
</div>
<script type="text/javascript">
    function categoryAdd() {
        var name = jQuery.trim(jQuery("#category_name").val());
        var sortby = jQuery.trim(jQuery("#category_sortby").val());
        if (name == "") {
            alert("名称不能为空！");
            //noinspection JSValidateTypes
            return false;
        } else if (!jQuery.isNumeric(sortby)) {
            alert("排序只能为数字！");
            //noinspection JSValidateTypes
            return false;
        }
        jQuery(".loader").show();
        name = encodeURIComponent(name);
        jQuery.post("<?php echo $base_url; ?>/admin.php?c=CategoryManage&a=add", {
            token: '<?php echo $token; ?>',
            name: name,
            sortby: sortby
        }, function (result) {
            jQuery(".loader").hide();
            if (confirm(result + "\n需要继续添加吗？")) {
                window.location = "<?php echo $base_url; ?>/admin.php?c=CategoryManage&a=add&token=<?php echo $token; ?>";
            } else {
                window.location = "<?php echo $base_url; ?>/admin.php?c=CategoryManage&token=<?php echo $token; ?>";
            }
        }, "text");
        //noinspection JSValidateTypes
        return false; //阻止表单提交
    }
</script><div style="width:100%;background:#FFFFFF;display:block;border-top:1px dotted #CCCCCC;position:fixed;bottom:0;">
    <div class="center">
        <?php echo isset($copyright) ? $copyright : ''; ?>
    </div>
</div>
</body>

</html>
<!-- Created By Template Engineer At 2016/07/27,22:39 -->
