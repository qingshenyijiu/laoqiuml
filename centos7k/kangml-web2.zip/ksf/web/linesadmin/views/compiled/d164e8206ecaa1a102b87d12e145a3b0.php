﻿<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"/>
    <meta name="MobileOptimized" content="320"/>
    <meta name="author" content="<?php echo $author; ?>"/>
    <meta name="robots" content="none"/>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/mui.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/default.js"></script>
    <title><?php echo $title; ?></title>
    <link type="image/x-icon" rel="icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link type="image/x-icon" rel="shortcut icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/mui.min.css" rel="stylesheet"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/default.css" rel="stylesheet"/>
    <style type="text/css">
        html, body {
            height: 100%;
            overflow: hidden;
            background: #FFFFFF;
        }

        .mui-content {
            padding: 10px;
            background: #FFFFFF;
        }

        .mui-table-view:after {
            height: 0;
        }

        .mui-table-view-cell:after {
            left: 1px;
        }

        .mui-input-group .mui-input-row::after {
            left: 0;
        }

        .mui-input-group::before,
        .mui-input-group::after {
            height: 0;
        }

        .mui-btn {
            padding: 5px;
        }
    </style>
</head>

<body>
<noscript class="error">
    很遗憾，由于你的浏览器不支持或禁用了JavaScript，导致无法获得正常体验。
</noscript><header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left" href="javascript:history.back();"></a>

    <h1 class="mui-title"><?php echo $title; ?></h1>
</header>
<div class="mui-content">
    <form class="mui-input-group">
        <h5>新的密码：</h5>

        <div class="mui-input-row">
            <input type="password" name="userPass1" value="" id="userPass1" class="mui-input-clear mui-input"
                   placeholder="这里输入新密码" onClick="this.select()"/>
        </div>
        <h5>确认密码：</h5>

        <div class="mui-input-row">
            <input type="password" name="userPass2" value="" id="userPass2" class="mui-input-clear mui-input"
                   placeholder="再次输入新密码"/>
        </div>
    </form>
    <div class="mui-content-padded">
        <button class="mui-btn mui-btn-block mui-btn-primary" onclick="modifyPassword()">修改</button>
    </div>
    <div class="loader hide"></div>
</div>
<script type="text/javascript">
    function modifyPassword() {
        var userPass1 = jQuery.trim(jQuery("#userPass1").val());
        var userPass2 = jQuery.trim(jQuery("#userPass2").val());
        if (userPass1 == "") {
            alert("用户密码不能为空！");
            return false;
        } else if (userPass1 != userPass2) {
            alert("两次输入的密码不一致！");
            return false;
        }
        jQuery(".loader").show();
        userPass1 = encodeURIComponent(userPass1);
        jQuery.post("<?php echo $base_url; ?>/api.php?c=User&a=modifyPassword", {
            token: '<?php echo $token; ?>',
            password: userPass1,
        }, function (result) {
            jQuery(".loader").hide();
            alert(result.msg);
            if (result.code == 1) {
                window.location.reload();
            }
        }, "json");
        return false;
    }
</script><div style="width:100%;background:#FFFFFF;display:block;border-top:1px dotted #CCCCCC;position:fixed;bottom:0;">
    <div class="center">
        <?php echo isset($copyright) ? $copyright : ''; ?>
    </div>
</div>
</body>

</html>
<!-- Created By Template Engineer At 2016/08/13,18:49 -->
