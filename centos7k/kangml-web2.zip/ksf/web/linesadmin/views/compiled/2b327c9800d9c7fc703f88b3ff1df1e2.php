﻿<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"/>
    <meta name="MobileOptimized" content="320"/>
    <meta name="author" content="<?php echo $author; ?>"/>
    <meta name="robots" content="none"/>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/mui.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/default.js"></script>
    <title><?php echo $title; ?></title>
    <link type="image/x-icon" rel="icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link type="image/x-icon" rel="shortcut icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/mui.min.css" rel="stylesheet"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/default.css" rel="stylesheet"/>
    <style type="text/css">
        html, body {
            height: 100%;
            overflow: hidden;
            background: #FFFFFF;
        }

        .mui-content {
            padding: 10px;
            background: #FFFFFF;
        }

        .mui-table-view:after {
            height: 0;
        }

        .mui-table-view-cell:after {
            left: 1px;
        }

        .mui-input-group .mui-input-row::after {
            left: 0;
        }

        .mui-input-group::before,
        .mui-input-group::after {
            height: 0;
        }

        .mui-btn {
            padding: 5px;
        }
    </style>
</head>

<body>
<noscript class="error">
    很遗憾，由于你的浏览器不支持或禁用了JavaScript，导致无法获得正常体验。
</noscript><header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left" href="javascript:history.back();"></a>

    <h1 class="mui-title"><?php echo $title; ?></h1>
</header>
<div class="mui-content">
    <?php $count = isset($links) ? count($links) : 0; ?>
    <?php if ($count < 1) { ?>
    <p class="center hint">暂时还没有对接，<a href="<?php echo $base_url; ?>/admin.php?c=LinkManage&a=add&token=<?php echo $token; ?>" class="active">点此添加</a>一个吧！
    </p>
    <?php } else { ?>
    <ul class="mui-table-view content">
        <?php $page_size = 7; ?>
        <?php $page_index = isset($_GET['page']) ? intval($_GET['page']) : 1; ?>
        <?php $pager = new Pager($count, $page_index, $page_size); ?>
        <?php for ($i=$pager->getStartNum(); $i<=$pager->getEndNum(); $i++) {?>
        <li class="mui-table-view-cell mui-media">
            <a href="<?php echo $links[$i-1]['url']; ?>" target="_blank" id="link_<?php echo $links[$i-1]['id']; ?>">
                <div class="mui-media-body mui-pull-left">
                    <?php echo $i; ?>
                    <?php echo Ubb::decode($links[$i-1]['name']); ?>
                    <p class='mui-ellipsis'>
                        <a href="<?php echo $base_url; ?>/admin.php?c=LinkManage&a=modify&token=<?php echo $token; ?>&id=<?php echo $links[$i-1]['id']; ?>">编辑</a> |
                        <a href="javascript:linkDelete(<?php echo $links[$i-1]['id']; ?>);">删除</a>
                    </p>
                </div>
                <img class="mui-media-object mui-pull-right" src="<?php echo $links[$i-1]['icon']; ?>" width="50" height="40">
            </a>
        </li>
        <?php } ?>
    </ul>
    <?php if ($count > $page_size) { ?>
    <ul class="mui-pager">
        <li>
            <?php echo $pager->getPrevPage(); ?>
        </li>
        <li>
            <?php echo $pager->getNextPage(); ?>
        </li>
        <li>
            <span><?php echo $page_index; ?>/<?php echo $pager->getPageNum(); ?></span>
        </li>
    </ul>
    <?php } ?>
    <?php } ?>
</div>
<script type="text/javascript">
    function linkDelete(id) {
        var url = jQuery.trim(jQuery("#link_" + id).text());
        if (confirm("真的要删除《" + url + "》吗？\n删除后不可恢复，请谨慎操作！")) {
            jQuery.post("<?php echo $base_url; ?>/admin.php?c=LinkManage&a=delete&id=" + id, {
                token: '<?php echo $token; ?>'
            }, function (result) {
                alert(result);
                if (result.lastIndexOf("成功") != -1) {
                    window.location.reload();
                }
            }, "text");
        }
    }
</script><div style="width:100%;background:#FFFFFF;display:block;border-top:1px dotted #CCCCCC;position:fixed;bottom:0;">
    <div class="center">
        <?php echo isset($copyright) ? $copyright : ''; ?>
    </div>
</div>
</body>

</html>
<!-- Created By Template Engineer At 2016/07/23,23:25 -->
