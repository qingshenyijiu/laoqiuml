<?php
/**
*本配置文件由安装程序自动生成，不可轻易修改
*/

return array (
  'base_url' => 'http://localhost/linesadmin',
  'db.type' => 'mysql',
  'db.host' => 'ip',
  'db.port' => '3306',
  'db.user' => 'root',
  'db.pass' => 'sqlpass',
  'db.name' => 'mycms',
)
?>