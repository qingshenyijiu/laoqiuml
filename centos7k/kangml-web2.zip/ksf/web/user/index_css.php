<html lang="zh">
  
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title><?=$title?></title>
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
    <link href="./index/css/bootstrap.min.css" rel="stylesheet">
    <link href="./index/css/client.css" rel="stylesheet">
    <script src="./index/js/jquery-1.11.3.min.js"></script>
    <script src="./index/js/bootstrap.min.js"></script>
    <script src="./index/js/retina.min.js"></script>
    <!--[if lt IE 9]>
      <script src="./index/js/html5shiv-3.7.2.min.js"></script>
      <script src="./index/js/respond-1.4.2.min.js"></script>
      <script src="./index/js/ie9-warning.js"></script>
    <![endif]-->
    <script src="./index/js/client.js"></script>
  </head>