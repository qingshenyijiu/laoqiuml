<?php
include "header.php";
$title='账号列表';
?>
<section class="panel panel-default">
              <div class="panel-body"> <header class="panel-heading font-bold"> 套餐列表 </header><hr/>
			
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="panel panel-primary">

<div class="panel-body box">';
$tcname=$_GET['tcname'];
$sql=$DB->query("DELETE FROM `tc_name` WHERE name='$tcname'");
if($sql){echo '恭喜你删除成功！';}
else{echo '删除失败！';}
echo '<hr/><a href="./tclist.php">【返回套餐列表】</a></div></div>';
}else
{
if(!empty($_GET['kw'])) {
	$sql=" `name`='{$_GET['kw']}'";
	$numrows=$DB->count("SELECT count(*) from `openvpn` WHERE {$sql}");
	$con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个套餐';
}else{
	$numrows=$DB->count("SELECT count(*) from `tc_name` WHERE 1");
	$sql=" 1";
	
}
echo '<form action="tclist.php" method="get" class="form-inline">
  <div class="form-group">
    <input type="text" class="form-control" name="kw" placeholder="套餐">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
  <a href="tcgl.php" class="btn btn-success">添加套餐</a>
  <a  class="btn btn-info">平台共有 <b>'.$numrows.'</b> 个套餐</a>
</form>';
echo $con;
?>  <!--<a href="delete.php" class="btn btn-danger" onclick="del();">删除选中</a>--><div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">	   
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th><input type="checkbox" id="widuu" onclick="checkAll(this)"></th><th>套餐名</th><th>套餐ID</th><th>总流量</th><th>套餐时长</th><th>套餐价格</th><th>备注</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM `tc_name` WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{ ?>
<tr>
<td><input type="checkbox" name="ids" value="<?=$res['id']?>" id="box"></td>
<td><?=$res['name']?></td><td><?=$res['id']?></td><td><?=round(($res['maxll'])/1024/1024)?>MB</td>
<td><?=$res['tcsc']?></td><td><?=$res['price']?></td><td><?=$res['notes']?></td>
<td><?=($res['state']?'开通':'禁用')?></td>
<td><a class="btn btn-xs btn-success" href="./tcset.php?tcname=<?=$res['name']?>">配置</a>&nbsp;<a href="./tclist.php?my=del&tcname=<?=$res['name']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
</tr>

<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="tclist.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="tclist.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="tclist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="tclist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="tclist.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="tclist.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>
  </div>
<script type="text/javascript">
    function del(){
      var str="";
      $("input[name='ids']").each(function(){ 
          if($(this).prop('checked')){
            str += $(this).val()+","
          }
      })
      $.post('delall.php?action=delall',{ids:str},function(data){
        alert(data);
        window.location.reload();
      });
      
    }
   function checkAll(obj){
      $("input[type='checkbox']").prop('checked', $(obj).prop('checked'));
  }

</script>
                  
                    
                  
              </div>

</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<?php
require_once ("footer.php");
?>