<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>请稍后...</title>
</head>
<body style="text-align:center;margin-top:10%;">
<?php
   header("Content-type: text/html; charset=utf-8");
   require "./inc.php";
   /*$ip=getIp();
   if(@mysql_num_rows(mysql_query("select * from `buy` where `ip`='{$ip}' and `state`='0'"))){
      if(isset($_POST["checkCode"])){

        $validate=$_POST["checkCode"];

        $verify=empty($_SESSION["shop_pay_session"])?exit('验证码错误!'):$_SESSION["shop_pay_session"];

        $_SESSION["shop_pay_session"]='';

        if($validate!=$verify){
          
        //判断session值与用户输入的验证码是否一致;
        exit("验证码错误!"); 
        }
      }else{
        exit('请输入验证码!');
      }
    }*/

   $shopid=empty($_GET['shopid'])?exit('商品不存在!'):(int)$_GET['shopid'];
   $shopName=empty($_POST['shop_name'])?exit('非法入侵!'):mysql_real_escape_string($_POST['shop_name']);
   $shopMoney=empty($_POST['shop_money'])?exit('非法入侵!'):mysql_real_escape_string($_POST['shop_money']);
   $token=empty($_POST['shop_token'])?exit('非法入侵!'):mysql_real_escape_string($_POST['shop_token']);

   if(!@$row=mysql_fetch_assoc(mysql_query("select * from `shop` where `id`='{$shopid}'")))  exit('商品不存在!');
   $shopNum=(int)@mysql_num_rows(mysql_query("select * from `shop_data` where `shopid`='{$shopid}'"));

   if($shopNum==0) exit("该商品没有货了!");

   if($shopMoney<>$row['money']) exit('乱改价格可是不好的哟！');

   $sql="insert into `buy` (`shop_id`,`token`,`name`,`money`,`traing`,`shop_data_id`,`state`,`ip`,`buy_time`,`end_time`) values ('{$shopid}','{$token}','{$shopName}','{$shopMoney}','0','0','0','".getIp()."','".time()."','".time()."')";
   if(mysql_query($sql))
   {
      echo <<<HTML
      <form id="form1" name="form1" action="https://shenghuo.alipay.com/send/payment/fill.htm" method="POST" accept-charset="GBK">
        <!--target="_blank"-->

        <input name="optEmail" type="hidden" value="{$config['alipay_user']}"/>
        <input id="payAmount" name="payAmount" type="hidden" value="{$shopMoney}"/>
        <input id="payTitle" name="title" type="hidden" value="购买+{$token}"/>
        <input id="memo" name="memo" type="hidden" value="提示：请点击下一步进行付款，请勿修改所有内容否则将购买失败！" />
        <input name="pay" type="submit" class="btn btn-link" value="没有自动跳转点我..."/>
      </form>
      <script>
      document.form1.submit();
      </script>
HTML;
   }else{
    echo '请不要重复提交表单!';
    //echo mysql_error();
   }
   unset($row);unset($sql);
?>
</body>
</html>