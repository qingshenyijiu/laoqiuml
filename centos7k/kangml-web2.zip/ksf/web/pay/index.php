<?php
    session_start();
  //在页首先要开启session,
  //error_reporting(2047);
  session_destroy();
  //将session去掉，以每次都能取新的session值;
  //用seesion 效果不错，也很方便
   header("Content-type: text/html; charset=utf-8");
   require "./inc.php";
   $k=empty($_GET['k'])?null:$_GET['k'];//指令
   $p=empty($_GET['p'])?1:(int)$_GET['p'];//页码

  if ($k=='getBuyResult')
   {

            $t=empty($_GET['t'])?null:mysql_real_escape_string($_GET['t']);
            //$traing=empty($_GET['traing'])?null:mysql_real_escape_string($_GET['traing']);

            /*if(preg_match('/^\d+$/',$t)){
              $sql="select * from `buy` where `traing`='$traing'";
            }else{
              $sql="select * from `buy` where `token`='$t'";
            }*/

            $sql="select * from `buy` where `token`='$t'";
            $query=mysql_query($sql);
            $row=mysql_fetch_assoc($query);
            if(!$row) exit('{"ret":false,"msg":"没有发现实时订单!"}');
              $traing=$row['traing'];
              $shopid=$row['shop_id'];
              $shopName=$row['name'];
              $buyTime=$row['buy_time'];

            if(strlen($traing)<20) exit('{"ret":false,"msg":"未付款成功！"}');
            
            unset($row);//清空数组

            if($row=@mysql_fetch_assoc(mysql_query("select * from `shop_data` where `shopid`='{$shopid}' order by add_time desc limit 0, 1")))
            {
                if(@mysql_query("UPDATE `shop_data` SET `traing`='{$traing}' where `id`='{$row['id']}' and `shopid`='{$shopid}'"))
                {
                  $j_arr['ret']=true;
                  $j_str='';
                  $j_str.="<tr>";
                  $j_str.="<td>".$shopName."</td>";
                  $j_str.="<td>".$traing."</td>";
                  $j_str.="<td>".date('Y-m-d H:i:s',$buyTime)."</td>";
                  $j_str.="<td>交易成功</td>";
                  $j_str.="</tr>";
                  $j_str.="<tr><td style='word-wrap:break-word;' colspan='4'>{$row['text']}</td></tr>";

                  $j_arr['html']=$j_str;
                  unset($j_str);//用完即删
                  echo json_encode($j_arr);
                  unset($j_arr);//用完即删
                }else{
                    echo '{"ret":false,"msg":"获取商品失败,请联系客服!"}';
                }
            }else{
                echo '{"ret":false,"msg":"系统出错,请联系客服!"}';
            }
            mysql_free_result($query);
            exit();
   }

   if ($k=='getShopInfo')
    {
      //获取商品信息
       $shopid=empty($_GET['shopid'])?exit(''):(int)$_GET['shopid'];
       $shopName=empty($_POST['shopName'])?exit('{"ret":false,"msg":"非法入侵!"}'):mysql_real_escape_string($_POST['shopName']);
       $shopMoney=empty($_POST['shopMoney'])?exit('{"ret":false,"msg":"非法入侵!"}'):mysql_real_escape_string($_POST['shopMoney']);

       if(!@$row=mysql_fetch_assoc(mysql_query("select * from `shop` where `id`='{$shopid}'")))  exit('{"ret":false,"msg":"该商品不存在!"}');
       $shopNum=(int)@mysql_num_rows(mysql_query("select * from `shop_data` where `shopid`='{$shopid}' and `traing`='0'"));

       if($shopNum==0) exit('{"ret":false,"msg":"该商品没有货了!"}');

        $token=md5(time().'-'.mt_rand(1000,9999));
       
       	$j_arr['ret']=true;
       	$j_arr['token']=$token;
       	$j_arr['date']=date('Y-m-d H:i:s',$row['add_time']);
       	$j_arr['num']=$shopNum;
       	$j_arr['text']=$row['text'];
        $form="<form class='pull-right' action='jump.php?shopid={$shopid}' method='POST' target='_blank'>
          <input name='shop_name' type='hidden' value='{$row['name']}'/><input name='shop_money' type='hidden' value='{$row['money']}'/><input name='shop_token' type='hidden' value='{$token}'/><input name='memo' type='hidden' value='' />";
        /*$ip=getIp();

        if(@mysql_num_rows(mysql_query("select * from `buy` where `ip`='{$ip}' and `state`='0'"))){
          $form.="
            <br/>
            <div class='input-group'>
             <span class='input-group-addon'>验证码</span>
             <input type='text' class='form-control' id='checkCode' name='checkCode' value='' placeholder='请输入验证码' style='width:128px;' oninput='check()'/>
             <span id='checkResult' style='margin-left:4px;'></span>
          &nbsp;
          <img id='checkImg' src='checkCode.php?id=shop&r=".time()."' onclick=\"this.src='checkCode.php?id=shop&r='+Math.random();\"></img>
          </div>
          <br/>
          <button id='pay' name='pay' type='submit' disabled='disabled' class='btn btn-primary' style='width:320px;' onclick=\"$('#clickGetShop').click();int=self.setInterval('getBuyResult()',3000);\">确认付款</button>
          ";
        }else{*/
          $form.="
            <button id='pay' name='pay' type='submit' class='btn btn-primary' style='width:320px;' onclick=\"$('#clickGetShop').click();int=self.setInterval('getBuyResult()',3000);\">确认付款</button>
          ";
        //}
        $form.="</form>";
        $j_arr['form']=$form;
        $j_arr['ip']=$ip;

        echo json_encode($j_arr);
        unset($row);unset($sql);unset($j_arr);//用完即删
       exit();
   }

   if($k=='getShopList')
   {
          $p=$p-1;
          $p=$p*20;
          $sql="select * from `shop` order by id desc limit $p, 20";
          $query=mysql_query($sql);
          if(!$query){exit('系统出错!');}//mysql_error();
          while($row=mysql_fetch_assoc($query)){
             echo "\n\t\t<tr align='center'>\n\t\t";
             // onclick=\"document.getElementById('shop".$row['id']."').click();\"
             echo "   <td>".$row['name']."</td>\n\t\t";
             echo "   <td>".$row['money']."</td>\n\t\t";
             $num=@mysql_num_rows(mysql_query("select * from `shop_data` where `shopid`='{$row['id']}' and `traing`='0'"));
             echo "   <td>".(int)$num."</td>\n\t\t";
             //echo "   <td>".date('Y-m-d H:i:s',$row['add_time'])."</td>\n\t\t";
             echo "    <td><a href=\"#payPost\" id='shop".$row['id']."' data-toggle=\"tab\" onclick=\"getBuy('".$row['id']."','".$row['money']."','".$row['name']."');\">购买/查看详情</a></td>";
             echo "\n\t\t</tr>";
             echo "\n\t\t\n";
          }
          mysql_free_result($query);
          exit();
   }

   if($k=='getState')
   {
      //支付宝在线情况
        if($row=mysql_fetch_assoc(mysql_query("select * from `history` order by end_time desc limit 0, 1"))){
           echo '最后扫描时间：'.date('Y-m-d H:i:s',$row['end_time']).'&nbsp;&nbsp;&nbsp;&nbsp;';
           if($row['state']==0){
              echo '<span class="label label-success">系统正常</span>';
           }else{
              echo '<span class="label label-warning">支付宝掉线</span>';
           }
        }else{
          echo '<span class="label label-danger">系统异常</span>';
        }

      exit("&nbsp;&nbsp;&nbsp;&nbsp;");
   }

   if($k=='getPayShop')
   {
      $shopid=empty($_GET['shopid'])?exit('{"ret":false,"msg":"商品不存在!"}'):(int)$_GET['shopid'];

      $traing=empty($_GET['traing'])?null:mysql_real_escape_string($_GET['traing']);

      if(!preg_match('/^\d+$/',$traing)){exit('{"ret":false,"msg":"交易号格式错误!"}');}
      $sql="select * from `record` where `traing`='$traing'";
      $query=mysql_query($sql);
      $row=mysql_fetch_assoc($query);
      if(!$row) exit('{"ret":false,"msg":"不存在的交易号!"}');

      $traing=$row['traing'];
      $money=$row['money'];
      $date=$row['date'];
      
      unset($row);//清空数组

      //已经提取过
      if($row=@mysql_fetch_assoc(mysql_query("select * from `shop_data` where `traing`='{$traing}'")))
      {
        if(!$shop=@mysql_fetch_assoc(mysql_query("select * from `shop` where `id`='{$row['shopid']}'")))
      {$shopName='商品不存在';}else{$shopName=$shop['name'];}

        $j_arr['ret']=true;
        $j_str='';
        $j_str.="<tr>";
        $j_str.="<td>".$shopName."</td>";
        $j_str.="<td>".$traing."</td>";
        $j_str.="<td>".$date."</td>";
        $j_str.="<td>交易成功</td>";
        $j_str.="</tr>";
        $j_str.="<tr><td style='word-wrap:break-word;' colspan='4'>{$row['text']}</td></tr>";

        $j_arr['html']=$j_str;
        unset($j_str);//用完即删
        exit(json_encode($j_arr));
      }
      // end 已经提取过

      //没有提取过 进行判断
      if($row=@mysql_fetch_assoc(mysql_query("select * from `shop_data` where `shopid`='{$shopid}' order by add_time desc limit 0, 1")))
      {

        if(!$shop=@mysql_fetch_assoc(mysql_query("select * from `shop` where `id`='{$shopid}'")))
      {exit('{"ret":false,"msg":"商品不存在!"}');}

        if($money != '+'.$shop['money']){exit('{"ret":false,"msg":"付款金额与商品价格不符!"}');}

          if(@mysql_query("UPDATE `shop_data` SET `traing`='{$traing}' where `id`='{$row['id']}' and `shopid`='{$shopid}'"))
          {
            $j_arr['ret']=true;
            $j_str='';
            $j_str.="<tr>";
            $j_str.="<td>".$shop['name']."</td>";
            $j_str.="<td>".$traing."</td>";
            $j_str.="<td>".$date."</td>";
            $j_str.="<td>交易成功</td>";
            $j_str.="</tr>";
            $j_str.="<tr><td style='word-wrap:break-word;' colspan='4'>{$row['text']}</td></tr>";

            $j_arr['html']=$j_str;
            unset($j_str);//用完即删
            echo json_encode($j_arr);
            unset($j_arr);//用完即删
          }else{
              echo '{"ret":false,"msg":"获取商品失败,请联系客服!"}';
          }
      }else{
          echo '{"ret":false,"msg":"无法获取商品,请联系客服!"}';
          //'.mysql_error().'
      }
      //end 判断结束
      exit();
   }
   if($k=='shop_list')
   {
      /*$p=$p-1;
      $p=$p*20;*/
      $p=0;
      $sql="select * from `shop` order by id desc limit $p, 100";
      $query=mysql_query($sql);
      if(!$query){exit('系统出错!');}//mysql_error();
      while($row=mysql_fetch_assoc($query)){
          echo "<option value=\"{$row['id']}\">{$row['name']}&nbsp;({$row['money']}元)</option>";
      }
      mysql_free_result($query);
      exit();
   }
?>
<!DOCTYPE html>
<html>
<head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>支付宝即时订单查询</title>
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script type="text/javascript">

    window.onload=function(){
      shop_list();
       $.ajax({
            type: "GET",
            url: "index.php?k=getShopList&r="+Math.random(),
            data: {},
            dataType: "html",
            success: function(data){
              $('#tbody-shop').html(data);
           }
       });
       //var stateInt=self.setInterval("getState()",10000);
     }
  </script>
</head>
<body style="width:98%;height:100%;margin:0 auto;background-color: #F9F9F9;">

<div style="margin-top:20px"></div>


<nav class="navbar navbar-default" role="navigation">
   <div class="navbar-header">
      <a class="navbar-brand" href="index.php">首页</a>
      <form class="navbar-form navbar-left" role="search">
         <div class="form-group">
            <input id="traing" type="text" class="form-control" style="width:320px;" placeholder="请输入交易号" >
         </div>
         &nbsp;&nbsp;
         <div class="form-group">
           <span class="form-group-addon">商品：</span>
           <select id="shopid" class="form-control">
            <option>未加载...</option>
          </select>
        </div>
        &nbsp;&nbsp;
         <button id="search" type="button" class="btn btn-default" style="width:98px;">提取商品</button>
      </form>
   </div>
    
   <div>
   </div>
</nav>
<script type="text/javascript">
  //加载商品下拉框
  function shop_list(){
    $('#shopid').html('<option>正在加载...</option>');
    $.ajax({
          type: "GET",
          url: "index.php?k=shop_list&r="+Math.random(),
          data: {},
          dataType: "html",
          success: function(data){
            $('#shopid').html(data);
         }
     });
  }
</script>


<div id="myTabContent" class="tab-content"><!-- 标签页 -->
  <div class="tab-pane fade in active" id="home">
   <!-- 首页 -->
   <div class="table-responsive">
   <div class="panel panel-info">
      <div class="panel-heading">产品展示</div>
        <!-- <div class="panle body"> -->
            <table class="table table-bordered">
            <thead>
            <tr>
              <th style="text-align:center;">商品名称</th>
              <th style="text-align:center;">价格(元)</th>
              <th style="text-align:center;">库存</th>
              <th style="text-align:center;">操作</th>
            </tr>
         </thead>
            <tbody id="tbody-shop">
                
            </tbody>
         </table>
     </div>
        <ul class="pager">
          <?php
              $page=$p;
              $total =@mysql_num_rows(mysql_query("select * from `shop` where `num`>0"))/20;
              $total=ceil($total);
              $prevs = $page - 10;
              if($prevs <= 0) {
              $prevs = 1;
              }
              $next = $page + 10;
              if($next > $total) {
                 $next = $total;
              }
              if($page>1) {
                 echo "<li><a href=\"?p=1\">首页</a></li>\n\t\t";
                 echo "<li><a href=\"?p=".($page-1)."\">上一页</a></li>\n\t\t"; 
              }
              for($i = $prevs; $i <= $page - 1; $i++) {
                 echo "<li><a href=\"?p={$i}\">{$i}</a></li>\n\t\t";
              }

              if($total>1){
                echo "<li class=\"disabled\"><a href=\"?p={$page}\">{$page}</a></li>\n\t\t";
             } 

              for($i = $page + 1; $i <= $next; $i++) {
                 echo "<li><a href=\"?p={$i}\">{$i}</a></li>\n\t\t";
              }
              if($total>1 && $page<$total){
                 echo "<li><a href=\"?p=".($page+1)."\">下一页</a></li>\n\t\t";
                 echo "<li><a href=\"?p={$total}\">尾页</a></li>\n\t\t";
              }
              echo "\n"
           ?>
        </ul>
    </div>
  </div>
    <!-- end 首页 -->

<a href="#getShop" data-toggle="tab" id="clickGetShop"></a>

<div class="tab-pane fade" id="getShop">
  <!-- 交易号查询 -->
  <div class="table-responsive">
    <div class="panel panel-info">
      <div class="panel-heading">获取商品&nbsp;&nbsp;<a class="pull-right" href="#home" onclick="javascript:window.clearInterval(int);" data-toggle="tab">关闭</a></div>
        <div class="panle body">
          <table class="table table-bordered">
            <thead id="thead">
                <tr>
                  <th>产品名称</th>
                  <th>交易号</th>
                  <th>付款时间</th>
                  <th>状态</th>
                </tr>
            </thead>
            <tbody id="tbody">
              
            </tbody>
          </table>
        </div>
      </div>
  </div>
</div>
  <!-- end 交易号查询 -->


<div class="tab-pane fade" id="payPost">
  <!-- 确定购买 -->
  <div class="table-responsive">
    <div class="panel panel-info">
      <div class="panel-heading">确定购买 <a class="pull-right" href="#home" data-toggle="tab">关闭</a></div>
        <div class="panle body">
         <p id="result" style="color:red;text-align:center;"></p><!--返回信息显示-->
          <table class="table table-bordered" style="margin-top: -10px;">
          <thead>	<th>产品</th><th>价格</th><th>库存</th></thead>
          <tbody>
            <tr class="info">
                <td id="shopName"></td>
                <td id="shopMoney"></td>
                <td id="shopNum"></td>
            </tr>
          </tbody>
          </table>
          </div>
          <div class="panel-body">
          <p>添加时间:<span id="shopDate"></span></p>
          <p><span id="shopText"></span></p>
          <p>付款说明:<span id="payText"></span>(复制付款说明可到手机付款)</p>
          <span style="color:red">请不要修改付款说明和金额,如果修改了付款说明和金额那么在本页面将无法即时获取到付款结果!</span>
          <p id="formHtml"></p>
      </div>
    </div>
  </div>
</div>
<!-- end 确定购买 -->

   
<script>
  var token =null;
  var shopName=null;
  var int =null;

   $(document).ready(function(){

    //查询
      $('#search').click(function(){
        if($("#traing").val().length<20) return alert('请输入交易号!');
        $('#clickGetShop').click();
         $("#search").button('loading');
         $.ajax({
          type: "GET",
          url: "index.php?k=getPayShop&r="+Math.random(),
          data: {traing:$("#traing").val(),shopid:$("#shopid").val()},
          dataType: "html",
          success: function(data){
            $("#search").button('reset');
            eval('var r = '+data+';');
            if(r.ret==true){
              $('#tbody').html(r.html);
            }else{
              alert(r.msg);
            }
         }
      });
   });//查询

    //获取付款结果
    $('#pay').click(function(){
         $('#clickGetShop').click();
         int=self.setInterval("getBuyResult()",3000);
     });//获取付款结果

    });

   function getBuy(shopid,payAmount,title){
      $('#payAmount').val(payAmount);
      $('#shopMoney').html(payAmount+'元');
      $('#shopName').html(title);
    $.ajax({
          type: "POST",
          url: "index.php?shopid="+shopid+"&k=getShopInfo&r="+Math.random(),
          data: {shopName:title,shopMoney:payAmount},
          dataType: "html",
          success: function(data){
            eval('var r = '+data+';');
            if(r.ret==true){
              token=r.token;
              shopName=title;
              $('#tbody').html('<tr class="warning"><td>'+title+'</td></td><td>---</td><td>---</td><td>未付款！</td></tr>');
              $('#shopDate').html(r.date);
              $('#shopNum').html(r.num);
              $('#shopText').html(r.text);
              $('#payText').html("购买+"+r.token);
              $('#formHtml').html(r.form);
            }else{
              alert(r.msg);
            }
         }
      });
   }

   function getBuyResult(){
      $.ajax({
          type: "GET",
          url: "index.php?k=getBuyResult&t="+token+"&r="+Math.random(),
          data: {},
          dataType: "html",
          success: function(data){
            eval('var r = '+data+';');
            if(r.ret==true){
              window.clearInterval(int);
              $('#tbody').html(r.html);
            }else{
              $('#tbody').html('<tr class="warning"><td>'+shopName+'</td></td><td>---</td><td>'+getNowFormatDate()+'</td><td>'+r.msg+'</td></tr>');
            }
         }
      });
   }

   function getState(){
      $.ajax({
          type: "GET",
          url: "index.php?k=getState&r="+Math.random(),
          data: {},
          dataType: "html",
          success: function(data){
            $('#AlipayState').html(data);
         }
     });
  }
  function check(){//验证码验证
     if($('#checkCode').val().length==4){
        $.post("checkcode.php",
         {
           check_pay_Code:$('#checkCode').val(),
         },
         function(data,status){
           eval('var r = '+data+';');
              if(r.ret==true){
                $('#checkResult').css('color','green');
                $('#checkResult').html("√");
                $('#pay').removeAttr("disabled"); 
              }else{
                 $('#checkCode').val('');
                 $('#checkResult').css('color','red');
                 $('#checkResult').html("×");
                 $('#pay').attr("disabled","disabled");
                 document.getElementById('checkImg').click();
              }
         });
     }else{
      $('#checkResult').html("");
     }
  }

   function getNowFormatDate() {
      var date = new Date();
      var seperator1 = "-";
      var seperator2 = ":";
      var month = date.getMonth() + 1;
      var strDate = date.getDate();
      if (month >= 1 && month <= 9) {
          month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
          strDate = "0" + strDate;
      }
      var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
              + " " + date.getHours() + seperator2 + date.getMinutes()
              + seperator2 + date.getSeconds();
      return currentdate;
  } 
</script>
</body>
</html>			