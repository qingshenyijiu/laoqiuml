<?php
error_reporting(0);
define('ROOT', dirname(__FILE__).'/');

require ROOT.'config.php';
require ROOT.'http.func.php';

$scriptpath=str_replace('\\','/',$_SERVER['SCRIPT_NAME']);
$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));
$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].$sitepath.'/';

$conn=mysql_connect($db_host,$db_user,$db_pwd);
if(!$conn) die(mysql_error());
mysql_query("SET NAMES 'UTF8'");
mysql_select_db($db_name);

function getIp()
{
    static $realip;
    if (isset($_SERVER)){
        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
            $realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        } else if (isset($_SERVER["HTTP_CLIENT_IP"])) {
            $realip = $_SERVER["HTTP_CLIENT_IP"];
        } else {
            $realip = $_SERVER["REMOTE_ADDR"];
        }
    } else {
        if (getenv("HTTP_X_FORWARDED_FOR")){
            $realip = getenv("HTTP_X_FORWARDED_FOR");
        } else if (getenv("HTTP_CLIENT_IP")) {
            $realip = getenv("HTTP_CLIENT_IP");
        } else {
            $realip = getenv("REMOTE_ADDR");
        }
    }
    return $realip;
}
function send_mail() {
	global $config,$siteurl;
	include_once ROOT.'smtp.class.php';
	$to = $config['smtpemailto'];
	$From = $config['smtpuser'];
	$Host = $config['smtpserver'];
	$Port = $config['smtpserverport'];
	$SMTPAuth = 1;
	$Username = $config['smtpuser'];
	$Password = $config['smtppass'];
	$Nickname = '支付宝免签约卡密销售平台';
	$sub = '支付宝掉线提醒';//邮件主题
	$msg = '<h1>支付宝掉线提醒</h1><br/>您好！你在支付宝免签约卡密销售平台['.$_SERVER['HTTP_HOST'].']的支付宝账号 '.$config['alipay_user'].' 已经掉线，为了不影响卡密正常的销售，请尽快到 <a href="'.$siteurl.'admin.php">'.$siteurl.'</a> 重新登录你的支付宝账号！<br/>----------<br/>'.date("Y-m-d H:i:s");//邮件内容
	$SSL = false;
	$mail = new SMTP($Host , $Port , $SMTPAuth , $Username , $Password , $SSL);
	$mail->att = array();
	if($mail->send($to , $From , $sub , $msg, $Nickname)) {
		return true;
	} else {
		return $mail->log;
	}
}
?>