<?php
//Mysql配置
$db_host = 'localhost'; //数据库服务器
$db_user = 'root'; //数据库用户名
$db_pwd = 'root'; //数据库密码
$db_name = 'test'; //数据库名

//收款，监控支付宝账号
$config['alipay_user']="lifespy@qq.com";

//邮件提醒
$config['emailSend']=false; //是否cookie失效时邮件提醒
$config['smtpemailto'] = "net909@163.com"; //收信邮箱
$config['smtpserver'] = "smtp.163.com"; //SMTP服务器
$config['smtpserverport'] = 25; //SMTP服务器端口
$config['smtpuser'] = "net909@163.com"; //发信邮箱账号
$config['smtppass'] = ""; //发信邮箱密码

//交易记录POST转发（无需开启）
$config['postSend']=false; //是否进行转发
$config['post_token']='123456'; //验证Token
$config['post_url']="https://awby.cn/api.php"; //转发到的地址
?>