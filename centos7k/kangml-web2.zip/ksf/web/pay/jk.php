<?php
	header("Content-type: text/html; charset=gbk");
	//if(function_exists('set_time_limit')) set_time_limit(0);
	//if(function_exists('ignore_user_abort')) ignore_user_abort();
	date_default_timezone_set('PRC');
	require "./inc.php";

	$html=Http_curl("https://lab.alipay.com:443/consume/record/items.htm");

	$setArray['referer']='https://lab.alipay.com/consume/record/items.htm';
	$html=Http_curl("https://consumeprod.alipay.com:443/record/advanced.htm?beginDate=".date('Y-m-d',strtotime('-1 month'))."&beginTime=00%3A00&endDate=".date('Y-m-d',time())."&endTime=24%3A00&dateRange=oneMonth&status=success&keyword=bizOutNo&keyValue=&dateType=payDate&minAmount=&maxAmount=&fundFlow=in&tradeModes=FP&tradeType=TRANSFER&categoryId=&_input_charset=utf-8");

	//echo $html;

	$pattern='@<p class="time-d">.*([\d]{4}+\.[\d]{2}+\.[\d]{2}+)[^class]+.*([\d]{2}+:+[\d]{2}+)[^_b]+.*_blank">([^<]+)</a>[^class]+.*:([^<]+)</p>[^p]+p class="name">\s.*(\S.*)\s.*<[^i]+in">([^<]+)</sp[^p]+<p>([^<]+)<@isU';//正则表达式
	mysql_query("delete from `history` where `end_time`<".(time()-30*60)."");//删除30分钟前的记录
	mysql_query("delete from `buy` where `traing`='0' and `buy_time`<".(time()-20*60)."");//删除20分钟前未付款的记录
	//echo mysql_error();
	if(preg_match_all($pattern, $html, $matches)){
		//print_r($matches);
		$num=count($matches[1]);
		$array=array();
		mysql_query("insert into `history` (`state`,`end_time`) values ('0','".time()."')");
		for ($i=0; $i < $num; $i++) {

			$date=$matches[1][$i]." ".$matches[2][$i];
			$name=mb_convert_encoding($matches[3][$i], "UTF-8", "GBK");
			$traing=$matches[4][$i];
			$toname=json_decode('{"name":"'.mb_convert_encoding($matches[5][$i], "UTF-8", "GBK").'"}');
			//echo $toname->name.'<br/>';
			$money=$matches[6][$i];
			$state=mb_convert_encoding($matches[7][$i], "UTF-8", "GBK");

			//截取token实时获取付款结果
			$bzAndQm=explode("+",$name);
			if(array_key_exists(1,$bzAndQm)){
				if($state=='交易成功'){

					$buy=@mysql_fetch_assoc(mysql_query("select * from `buy` where `token`='{$bzAndQm[1]}'"));

					if('+'.$buy['money']==$money){//金额判断
						updateShop($bzAndQm[1],$traing,1);
					}
				}
			}//判断 截取token实时获取付款结果 完毕

			$sql="insert into `record` (`date`,`name`,`traing`,`toname`,`money`,`state`,`add_time`) values ('{$date}','{$name}','{$traing}','".$toname->name."','{$money}','{$state}','".time()."')";

			if(mysql_query($sql)){//有新交易，插入成功
				$j_arr['date']=$date;
				$j_arr['name']=$name;
				$j_arr['traing']=$traing;
				$j_arr['toname']=$toname->name;
				$j_arr['money']=$money;
				$j_arr['state']=$state;
				$array['result'][]=$j_arr;
				unset($j_arr);
			}
				//调试使用
				/*$j_arr['date']=$date;
				$j_arr['name']=$name;
				$j_arr['traing']=$traing;
				$j_arr['toname']=$toname->name;
				$j_arr['money']=$money;
				$j_arr['state']=$state;
				$array['result'][]=$j_arr;
				print_r($j_arr);
				echo '<hr>';
				unset($j_arr);*/

		}//end for
		if(!empty($array['result']) && $config['postSend']==true){
			/*echo '不为空 and 开通转发 那就 转发<hr>';
			echo json_encode($array);*/
			$setArray['cookie']='';
			$setArray['post']='token='.$config['post_token'].'&json='.urlencode(json_encode($array));
			Http_curl($config['post_url'],$rcookie,$setArray);
			unset($setArray);
		}/*else{
			echo '为空 or 不转发<hr>';
			echo json_encode($array);
		}*/
		unset($array);unset($json);unset($matches);
		echo 'ok';
		
	}elseif(preg_match("@https://auth.alipay.com/login/logout.htm@i",$html)){
		echo 'ok';
	}else{
		echo 'error';
		@mysql_query("insert into `history` (`state`,`end_time`) values ('1','".time()."')");
		
		if($config['emailSend']==true)
		{
			send_mail();
		}//end 邮件提醒
	}

	function updateShop($token,$traing,$state=0){//更改付款状态
		if(strlen($token) !== 32) return '不合适!';//token为32位
		if(!mysql_num_rows(mysql_query("select * from `buy` where `token`='{$token}' and `traing`<>'{$traing}'"))){
			return '没有!';
		}
		if(mysql_query("UPDATE `buy` SET `traing`='{$traing}',`state`='{$state}' where `token`='{$token}'")){
			return '成功!';
		}else{
			return "失败!";
		}
	}	
?>