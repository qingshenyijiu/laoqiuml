<?php
   header("Content-type: text/html; charset=utf-8");
   require "./inc.php";
   //授权访问
   $token=empty($_COOKIE['token'])?exit("<script language='javascript'>window.location.href='./login.php';</script>"):$_COOKIE['token'];

   $token=mysql_real_escape_string($token);
   $sql="select * from `admin` where `token`='$token'";
   if(!mysql_num_rows(mysql_query($sql)))  exit("<script language='javascript'>window.location.href='./login.php';</script>");

   $k=empty($_GET['k'])?null:$_GET['k'];//指令
   $p=empty($_GET['p'])?1:(int)$_GET['p'];//页码

   if($k=='edit_pass')
   {
      //修改密码
      $y_pass=empty($_POST['y_pass'])?exit("请输入原密码！"):md5($_POST['y_pass']);
      $n_pass=empty($_POST['n_pass'])?exit("请输入新密码！"):md5($_POST['n_pass']);

      if(!mysql_num_rows(mysql_query("select * from `admin` where `token`='$token' and `pass`='$y_pass'")))
      {
        exit('<div class="alert alert-danger alert-dismissable">
               <button type="button" class="close" data-dismiss="alert" 
                  aria-hidden="true">
                  &times;
               </button>原密码不正确！
             </div>
            ');
      }

      if(mysql_query("UPDATE `admin` SET `pass`='{$n_pass}' where `token`='$token'"))
      {

         echo '<div class="alert alert-success alert-dismissable">
               <button type="button" class="close" data-dismiss="alert" 
                  aria-hidden="true">
                  &times;
               </button>
               密码修改成功,下次请使用新密码登陆!
            </div>';

      }else{

         echo '<div class="alert alert-danger alert-dismissable">
               <button type="button" class="close" data-dismiss="alert" 
                  aria-hidden="true">
                  &times;
               </button>原密码不正确！
             </div>
            ';
      }
      exit();//修改密码
   }

   if ($k=='search')
   {
      //交易记录查询
      $traing=empty($_GET['traing'])?null:mysql_real_escape_string($_GET['traing']);
      $p=$p-1;
      $p=$p*20;

      if($traing==null){$sql="select * from `record` order by date desc limit {$p}, 100";} 

      if(preg_match('/^\d+$/',$traing)){
        $sql="select * from `record` where `traing`='{$traing}' order by date desc limit {$p}, 100";
      }else{
      //不是交易号，模糊搜索
          $sql="select * from `record` where `name` like '%{$traing}%' order by date desc limit {$p}, 100";
      }

      $query=mysql_query($sql);
      while($row=mysql_fetch_assoc($query)){
         echo "\t\t<tr>\n\t\t";
         echo "   <td>".$row['id']."</td>\n\t\t";
         echo "   <td>".$row['date']."</td>\n\t\t";
         echo "   <td>".$row['name']."</td>\n\t\t";
         echo "   <td>".$row['traing']."</td>\n\t\t";
         echo "   <td>".$row['toname']."</td>\n\t\t";
         echo "   <td>".$row['money']."</td>\n\t\t";
         echo "   <td>".$row['state']."</td>\n\t\t";
         echo "   <td>".date('Y-m-d H:i:s',$row['add_time'])."</td>\n\t\t";
         echo "</tr>";
         echo "\n\t\n";
      }
      exit();//交易记录查询
   }

   if($k=='getAlipayLoginForm')
   {
    //获取登录表单
      $html=Http_curl("https://auth.alipay.com/login/home.htm?redirectType=parent",$rcookie,array(),array(),$header);

      if(strpos($header, "alipayUserInfo")>0) exit('<div class="alert alert-success alert-dismissable">支付宝已经登陆在线，无需重复登陆!</div>');
      //提取一些必要的参数
      $rds_form_token=getSubstr($html,'<input type="hidden" value="','" name="rds_form_token');
      $passwordSecurityId=getSubstr($html,'passwordSecurityId" value="','" />');
      $qrCodeSecurityId=getSubstr($html,'qrCodeSecurityId" value="','" />');
      $alieditUid=getSubstr($html,'name="alieditUid" value="','" />');
      $checkcode_img_url=urlencode(getSubstr($html,'sl-checkcode-img" src="','&'));

     /*<input type='hidden' id='rds_form_token' name='rds_form_token' value='{$rds_form_token}'/>
     <input type='hidden' id='passwordSecurityId' name='passwordSecurityId' value='{$passwordSecurityId}'/>
     <input type='hidden' id='qrCodeSecurityId' name='qrCodeSecurityId' value='{$qrCodeSecurityId}'/>
     <input type='hidden' id='alieditUid' name='alieditUid' value='{$alieditUid}'/>*/

      //生成表单
      $form="
          <p id='AlipayLoginResult' style='color:red;text-align:center;'></p>
          <form class='bs-example bs-example-form' role='form'>
           <div class='input-group'>
             <span class='input-group-addon'>账户</span>
             <input type='text' class='form-control' id='logonId' name='logonId' value='' placeholder='请输入支付宝账户名'/>
            </div><br/>
            <div class='input-group'>
             <span class='input-group-addon'>密码</span>
             <input type='password' class='form-control' id='password' name='password' value='' placeholder='请输入支付宝登陆密码'/>
            </div><br/>
      ";

      //js 一些POST参数

      $jsStr=<<<HTML
      <script>
      var checkcode_img_url='{$checkcode_img_url}';
      function AlipayLogin(){
        $("#Alipaylogin").button('loading');
             $.ajax({
              type: "POST",
              url: "admin.php?k=AlipayLogin",
              data: {rds_form_token:'{$rds_form_token}',passwordSecurityId:'{$passwordSecurityId}',qrCodeSecurityId:'{$qrCodeSecurityId}',alieditUid:'{$alieditUid}',checkCode:$('#checkCode').val(),logonId:$('#logonId').val(),password:$('#password').val(),password_input:$('#password').val()},
              dataType: "html",
              success: function(data){
                $("#Alipaylogin").button('reset');
                alert(data);
             }
         });
      }
    </script>
HTML;

      if(preg_match('/^http/', $checkcode_img_url)){
         $form.="<div class='input-group'>
         <span class='input-group-addon'>验证码</span>
         <input type='text' class='form-control' id='checkCode' name='checkCode' value='' placeholder='请输入验证码' style='width:128px;'/>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <img id='checkcodeImg' src='checkCode.php?url={$checkcode_img_url}&r=".time()."' onclick=\"this.src='checkCode.php?url='+checkcode_img_url+'&r='+Math.random();\"></img></div><br/>
      <div id='error' style='color:red'></div>";
      }

      $form.='<button id="Alipaylogin" onclick="AlipayLogin()" type="button" class="btn btn-default btn-lg btn-block">登陆支付宝</button>';

      echo $form.$jsStr;
      exit();
   }

   if($k=='AlipayLogin' && isset($_POST))
   {
      $post='';
      foreach ($_POST as $key => $value) {
        $post.=$key.'='.$value.'&';
      }
      $post.='password_input='.$_POST['password'].'&support=000001&needTransfer=&CtrlVersion=1,1,0,1&loginScene=home&redirectType=parent&personalLoginError=&goto=&errorGoto=&json_tk=&superSwitch=true&noActiveX=false&J_aliedit_using=false&J_aliedit_key_hidn=password&J_aliedit_uid_hidn=alieditUid&REMOTE_PCID_NAME=_seaside_gogo_pcid&_seaside_gogo_pcid=&_seaside_gogo_=&_seaside_gogo_p=&J_aliedit_prod_type=&security_activeX_enabled=false&J_aliedit_net_info=&idPrefix=';
      $setArray['Post']=$post;
      
      $setHeader[]='X-Requested-With: XMLHttpRequest';
      $setHeader[]='Accept: text/javascript, text/html, application/xml, text/xml, */*';
      $setHeader[]='Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
      $setHeader[]='Mozilla/5.0 (Linux; Android 4.1.1; Nexus 7 Build/JRO03D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166  Safari/535.19';
      $setHeader[]='Referer: https://auth.alipay.com/login/home.htm?redirectType=parent';
      
      $html=Http_curl("https://authztg.alipay.com/login/index.htm",$rcookie,$setArray,$setHeader,$header);
      $html=mb_convert_encoding($html, "UTF-8", "GBK");

      $url=rtrim(getSubstr($header,"Location: ","\n"));//提取302跳转地址

      if(preg_match('/^https.*/',$url))
      {
        $setArray['Post']='';

        $html=Http_curl($url,$upcookie,$setArray);
        $html=mb_convert_encoding($html, "UTF-8", "GBK");

        $url=getSubstr($html,'parent.location.href = "','";');

        if(preg_match('/^https.*/',$url)){
          $html=Http_curl($url,$rcookie,$setArray);
          $html=mb_convert_encoding($html, "UTF-8", "GBK");
          echo '登陆成功!';
          /*echo '
            <script language="javascript" type="text/javascript">
                    window.location.href="admin.php";
              </script>
          ';*/
        }else
        {
          echo htmlspecialchars(getSubstr($html,'<span class="sl-error-text">','</span>'));
        }
        //echo htmlspecialchars(getSubstr($html,'<span class="sl-error-text">','</span>'));
      }else
      {
        echo htmlspecialchars(getSubstr($html,'<span class="sl-error-text">','</span>'));
      }
      exit();
   }

   if($k=='getState')
   {
      //支付宝在线情况
        if($row=mysql_fetch_assoc(mysql_query("select * from `history` order by end_time desc limit 0, 1"))){
           echo '最后扫描时间：'.date('Y-m-d H:i:s',$row['end_time']).'&nbsp;&nbsp;&nbsp;&nbsp;';
           if($row['state']==0){
              echo '<span class="label label-success">系统正常</span>';
           }else{
              echo '<span class="label label-warning">支付宝掉线</span>';
           }
        }else{
          echo '<span class="label label-danger">系统异常</span>';
        }

      exit("&nbsp;&nbsp;&nbsp;&nbsp;");
   }

   if($k=='shop_add')
   {
      $name=empty($_POST['name'])?exit("名称不能为空!"):mysql_real_escape_string($_POST['name']);
      $money=empty($_POST['money'])?exit("金额不能为0元!"):mysql_real_escape_string($_POST['money']);
      if($money*100<1){exit('金额不能小于0.01元！');}
      $text=empty($_POST['text'])?'':mysql_real_escape_string($_POST['text']);
      $sql="insert into `shop` (`name`,`money`,`text`,`end_time`,`add_time`) values ('{$name}','{$money}','{$text}','".time()."','".time()."')";
      if(mysql_query($sql)){exit('添加成功!');}
      else{exit('添加失败!');}

   }

   if($k=='shop_edit')
   {
	  $shopid=empty($_GET['shopid'])?exit('该商品不存在!'):mysql_real_escape_string($_GET['shopid']);
      $name=empty($_POST['name'])?exit("名称不能为空!"):mysql_real_escape_string($_POST['name']);
      $money=empty($_POST['money'])?exit("金额不能为0元!"):mysql_real_escape_string($_POST['money']);
      if($money*100<1){exit('金额不能小于0.01元！');}
      $text=empty($_POST['text'])?'':mysql_real_escape_string($_POST['text']);
      $sql="update `shop` set `name`='{$name}',`money`='{$money}',`text`='{$text}' where `id`='{$shopid}'";
      if(mysql_query($sql)){exit('修改成功!');}
      else{exit('修改失败!');}

   }

   if($k=='shop_data_add')
   {
      $shopid=empty($_GET['shopid'])?exit('该商品不存在!'):mysql_real_escape_string($_GET['shopid']);
      $shopid=(int)$shopid;
      $exp=empty($_POST['exp'])?'[br]':$_POST['exp'];
      $text=empty($_POST['text'])?'':$_POST['text'];
	  $text = mysql_real_escape_string(str_replace(array("\r\n", "\r", "\n"), "[br]", $text));
      $km=explode($exp,$text);
      $count=0;
	  $errors=0;
      
      foreach ($km as $key => $value)
      {
        //$key=$key+1
        $msg.=($key+1)."    ";
        if(strlen($value)<=1) continue;

          $sql="insert into `shop_data` (`shopid`,`text`,`traing`,`add_time`) values ('{$shopid}','{$value}','0','".time()."')";
          if(mysql_query($sql)){++$count;}
          else{++$errors;}

      }

    exit("共成功添加 ".$count." 条数据!");
   }

   if($k=='shop_data_edit')
   {
      $shopid=empty($_GET['shopid'])?exit('该商品不存在!'):mysql_real_escape_string($_GET['shopid']);
      $shopid=(int)$shopid;
      
        //$key=$key+1
        $msg.=($key+1)."    ";
        if(strlen($value)<=1) continue;

          $sql="insert into `shop_data` (`shopid`,`text`,`traing`,`add_time`) values ('{$shopid}','{$value}','0','".time()."')";
          if(mysql_query($sql)){++$count;}
          else{++$errors;}

    exit("共成功添加 ".$count." 条数据!");
   }

   if($k=='shopdata_del')
   {
	  $shopid=empty($_GET['shopid'])?exit('该商品不存在!'):mysql_real_escape_string($_GET['shopid']);
      $sql="delete from `shop` where `id`='{$shopid}' limit 1";
      if(mysql_query($sql)){exit('删除成功!');}
      else{exit('删除失败!');}

   }

   if($k=='shop_list')
   {
      /*$p=$p-1;
      $p=$p*20;*/
      $p=0;
      $sql="select * from `shop` order by id desc limit $p, 100";
      $query=mysql_query($sql);
      if(!$query){exit('系统出错!');}//mysql_error();
      while($row=mysql_fetch_assoc($query)){
          echo "<option value=\"{$row['id']}\">{$row['name']}&nbsp;({$row['money']}元)</option>";
      }
      mysql_free_result($query);
      exit();
   }
   if($k=='shop_list2')
   {
          $p=$p-1;
          $p=$p*20;
          $sql="select * from `shop` order by id asc limit $p, 20";
          $query=mysql_query($sql);
          if(!$query){exit('系统出错!');}//mysql_error();
          while($row=mysql_fetch_assoc($query)){
             echo "\n\t\t<tr align='center'>\n\t\t";
             // onclick=\"document.getElementById('shop".$row['id']."').click();\"
             echo "   <td>".$row['name']."</td>\n\t\t";
             echo "   <td>".$row['money']."</td>\n\t\t";
             $num=@mysql_num_rows(mysql_query("select * from `shop_data` where `shopid`='{$row['id']}' and `traing`='0'"));
             echo "   <td>".(int)$num."</td>\n\t\t";
             echo "   <td>".date('Y-m-d H:i:s',$row['add_time'])."</td>\n\t\t";
             //echo "   <td>".date('Y-m-d H:i:s',$row['add_time'])."</td>\n\t\t";
             echo "    <td><a href=\"#shop_view\" id='shop".$row['id']."' data-toggle=\"tab\" onclick=\"shop_edit('".$row['id']."','".$row['money']."','".$row['name']."');\">修改</a>&nbsp;<a href=\"#\" id='shopdel".$row['id']."' data-toggle=\"tab\" onclick=\"shop_del('".$row['id']."');\">删除</a></td>";
             echo "\n\t\t</tr>";
             echo "\n\t\t\n";
          }
          mysql_free_result($query);
          exit();
   }

   if($k=='shop_view')
   {
	   $shopid=empty($_GET['shopid'])?exit('该商品不存在!'):mysql_real_escape_string($_GET['shopid']);
	   $shopid=(int)$shopid;
	   $query=mysql_query("select * from `shop` where id='$shopid' limit 1");
	   if(!$query){exit('系统出错!');}//mysql_error();
	   while($row=mysql_fetch_assoc($query)){
		   echo json_encode($row);
		}
		mysql_free_result($query);
		exit();
   }

   if($k=='shopdata_list')
   {
          $p=$p-1;
          $p=$p*20;
          $sql="select * from `shop_data` order by id asc limit $p, 50";
          $query=mysql_query($sql);
          if(!$query){exit('系统出错!');}//mysql_error();
          while($row=mysql_fetch_assoc($query)){
            if(mb_strlen($row['text'])>50)
            {
              $shopText=substr($row['text'],0,50)."...";
            }else{
              $shopText=$row['text'];
            }
             echo "\n\t\t<tr align='center'>\n\t\t";
             // onclick=\"document.getElementById('shop".$row['id']."').click();\"
             echo "   <td>".$row['id']."</td>\n\t\t";
             $shop=@mysql_fetch_assoc(mysql_query("select * from `shop` where `id`='{$row['shopid']}'"));
             echo "   <td>".$shop['name']."</td>\n\t\t";
             echo "   <td>".$shopText."</td>\n\t\t";

             echo "   <td>".date('Y-m-d H:i:s',$row['add_time'])."</td>\n\t\t";
             //echo "   <td>".date('Y-m-d H:i:s',$row['add_time'])."</td>\n\t\t";
             echo "    <td><a href='#' id='shopdata".$row['id']."' data-toggle=\"tab\" onclick=\"shopdata_del('".$row['id']."','".$row['shopid']."','".$shop['name']."');\">删除</a></td>";
             echo "\n\t\t</tr>";
             echo "\n\t\t\n";
          }
          mysql_free_result($query);
          exit();
   }
?>
<!DOCTYPE html>
<html>
<head>
   <title>后台管理</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script type="text/javascript">
   //加载交易记录
   window.onload=function(){
     $.ajax({
          type: "GET",
          url: "admin.php?k=search&p=<?php echo $p; ?>",
          data: {},
          dataType: "html",
          success: function(data){
            $('#tbody').html(data);
         }
     });
     var stateInt=self.setInterval("getState()",30000);
   }
</script>
</head>
<body style="width:98%;height:100%;margin:0 auto;">

<nav class="navbar navbar-default" role="navigation" style="margin-top:10px;margin-bottom:-10px">
   <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">后台管理</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
	  </button>
	  <a class="navbar-brand">后台管理</a>
   </div>
   <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul id="myTab" class="nav navbar-nav">
         <li class="active">
            <a href="admin.php">交易记录</a>
         </li>
         <li>
            <a href="#shop_admin" onclick="shop_list2()" data-toggle="tab">商品管理</a>
         </li>
         <script type="text/javascript">
		 function shop_del(id) {
			if(confirm('你确实要删除此商品吗？')){}else{return false;}
			$.ajax({
				type: "GET",
				url: "admin.php?k=shopdata_del&shopid="+id+"&r="+Math.random(),
				dataType: "html",
				success: function(data,status){
					alert(data);
					shop_list2();
				}
			});
		}
          //商品管理
          function shop_list2(){
            document.getElementById('shop_text').value='';
            $('#shopid').html('<option>正在加载...</option>');
            $.ajax({
                  type: "GET",
                  url: "admin.php?k=shop_list2&r="+Math.random(),
                  data: {},
                  dataType: "html",
                  success: function(data){
                    $('#shop_tbody').html(data);
                 }
             });
          }
        </script>

        <li>
            <a href="#shopdata_admin" onclick="shopdata_list()" data-toggle="tab">卡密管理</a>
         </li>
        <script type="text/javascript">
		function shopdata_del(id,a,b) {
			if(confirm('你确实要删除此卡密吗？')){}else{return false;}
			$.ajax({
				type: "GET",
				url: "admin.php?k=shopdata_del&id="+id+"&r="+Math.random(),
				dataType: "html",
				success: function(data,status){
					alert(data);
					shopdata_list();
				}
			});
		}
          //加载卡密列表
          function shopdata_list(){
            $.ajax({
                  type: "GET",
                  url: "admin.php?k=shopdata_list&r="+Math.random(),
                  data: {},
                  dataType: "html",
                  success: function(data){
                    $('#shopdata_tbody').html(data);
                 }
             });
          }
        </script>

         <!-- <li>
            <a href="#shopdata_add_admin" onclick="shop_list()" data-toggle="tab">添加卡密</a>
         </li> -->
        <script type="text/javascript">
          //加载商品下拉框
          function shop_list(){
            document.getElementById('shop_data_text').value='';
            $('#shopid').html('<option>正在加载...</option>');
            $.ajax({
                  type: "GET",
                  url: "admin.php?k=shop_list&r="+Math.random(),
                  data: {},
                  dataType: "html",
                  success: function(data){
                    $('#shopid').html(data);
                 }
             });
          }
        </script>

         <li>
            <a href="#edit_admin_pass" data-toggle="tab">修改密码</a>
         </li>
      </ul>

      <ul id="myTab" class="nav navbar-nav pull-right">
        <li>
          <a href="#Alipay_login_form" class="navbar-right" data-toggle="tab" onclick="getAlipayFrom()">登陆支付宝</a>
        </li>
        <li>
          <a href="javascript:document.cookie='token=';window.location.href='login.php';">退出系统</a>
        </li>
      </ul>

      <p class="navbar-text navbar-right" id="AlipayState">
      </p>
    </div>
</nav>

<div id="myTabContent" class="tab-content" style="margin-top:2%;"><!-- 标签页 -->
   
   <div class="tab-pane fade in active" id="home">
   <!-- 首页 -->
          <div class="panel panel-default">
           <div class="panel-heading form-inline">
             <div class="form-group">
             <input id="traing" type="text" placeholder="请输入交易号或者付款说明关键词"  style="width:320px;" class="form-control">
			 </div>
             <button id="search" type="button" class="btn btn-primary">查找</button>
          </div>
           <table class="table table-bordered table-striped">
              <thead>
                 <tr>
                    <th>ID</th>
                <th>时间</th>
                <th>名称</th>
                <th>交易号</th>
                <th>对方名称</th>
                <th>付款金额</th>
                <th>状态</th>
                <th>入库时间</th>
                 </tr>
              </thead>
              <tbody id="tbody">

              </tbody>
           </table>
        </div>
        <ul class="pager">
          <?php
              $page=$p;
              $total =@mysql_num_rows(mysql_query("select * from `record`"))/20;
              $total=ceil($total);
              $prevs = $page - 10;
              if($prevs <= 0) {
              $prevs = 1;
              }
              $next = $page + 10;
              if($next > $total) {
                 $next = $total;
              }
              if($page>1) {
                 echo "<li><a href=\"?p=1\">首页</a></li>\n\t\t";
                 echo "<li><a href=\"?p=".($page-1)."\">上一页</a></li>\n\t\t";
              }
              for($i = $prevs; $i <= $page - 1; $i++) {
                 echo "<li><a href=\"?p={$i}\">{$i}</a></li>\n\t\t";
              }

             if($total>1){
                echo "<li class=\"disabled\"><a href=\"?p={$page}\">{$page}</a></li>\n\t\t";
             } 

              for($i = $page + 1; $i <= $next; $i++) {
                 echo "<li><a href=\"?p={$i}\">{$i}</a></li>\n\t\t";
              }
              if($total>1 && $page<$total){
                 echo "<li><a href=\"?p=".($page+1)."\">下一页</a></li>\n\t\t";
                 echo "<li><a href=\"?p={$total}\">尾页</a></li>\n\t\t";
              }
              echo "\n"
           ?>
        </ul>
   </div>
   <!-- end 首页 -->

   <div class="tab-pane fade" id="shop_admin">
   <!-- 商品管理 -->
        <div class="panel panel-default">
           <div class="panel-heading">商品管理
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <!-- <input id="shop_word" type="text"  style="width:320px;height: 24px;border: 1px solid #CCC;" placeholder="请输入关键词">
             <a href="javascript:void(0);" onclick="document.getElementById('shop_word').value='';" style="margin-left:-20px;">&times;</a>
             <button id="shop_search" type="button" style="margin-left:20px;width:98px;background-color: #FFF;border-color: #CCC;border: 1px solid transparent;">查找</button> -->
             <a class="pull-right" href="#shop_add_admin" data-toggle="tab" >添加商品</a>
          </div>
           <table class="table table-bordered table-striped">
              <thead>
              <tr>
                <th style="text-align:center;">商品名称</th>
                <th style="text-align:center;">价格(元)</th>
                <th style="text-align:center;">库存</th>
                <th style="text-align:center;">添加时间</th>
                <th style="text-align:center;">操作</th>
              </tr>
              </thead>
              <tbody id="shop_tbody">

              </tbody>
           </table>
        </div>


   </div>
   <!-- end 商品管理  -->


   <div class="tab-pane fade" id="shop_add_admin">
   <!-- 添加商品-->
      <div class="panel panel-default">
        <div class="panel-heading">添加商品    <a class="pull-right" href="#shop_admin" onclick="shop_list2()" data-toggle="tab">关闭</a></div>
          <div class="panle body" style="padding: 10px;">
            <form class="bs-example bs-example-form" role="form">
              <div class="input-group">
                 <span class="input-group-addon">名称</span>
                 <input id="shop_name" type="text" class="form-control" placeholder="请输入商品名称">
              </div>
              <br>
              <div class="input-group">
                 <span class="input-group-addon">价格</span>
                 <input id="shop_money" type="text" class="form-control" placeholder="请输入价格">
                 <span class="input-group-addon">元</span>
              </div>
              <br/>
              <div class="form-group">
                <label for="name">商品介绍</label>
                <textarea id="shop_text" class="form-control" rows="3"></textarea>
              </div>
                <button type="button" class="btn btn-primary" id="shop_add" style="width:99%;"
                 data-complete-text="Loading finished">确定添加
              </button>
            </form>
          </div>
       </div>
   </div>

   <script type="text/javascript">
   //ajax 添加商品
   $(document).ready(function(){
      $('#shop_add').click(function()
      {
         $("#shop_add").button('loading');
         $.post("admin.php?k=shop_add",
         {
          name:$('#shop_name').val(),money:$('#shop_money').val(),text:$('#shop_text').val()
         },
         function(data,status){
            alert(data);
            $("#shop_add").button('reset');
         });
     });
   });
   </script>
   <!-- end 添加商品 -->

   <div class="tab-pane fade" id="shop_view">
   <!-- 修改商品-->
      <div class="panel panel-default">
        <div class="panel-heading">修改商品    <a class="pull-right" href="#shop_admin" onclick="shop_list2()" data-toggle="tab">关闭</a></div>
          <div class="panle body" style="padding: 10px;">
            <form class="bs-example bs-example-form" role="form">
			<input id="shop_id1" type="hidden">
              <div class="input-group">
                 <span class="input-group-addon">名称</span>
                 <input id="shop_name1" type="text" class="form-control" placeholder="请输入商品名称">
              </div>
              <br>
              <div class="input-group">
                 <span class="input-group-addon">价格</span>
                 <input id="shop_money1" type="text" class="form-control" placeholder="请输入价格">
                 <span class="input-group-addon">元</span>
              </div>
              <br/>
              <div class="form-group">
                <label for="name">商品介绍</label>
                <textarea id="shop_text1" class="form-control" rows="3"></textarea>
              </div>
                <button type="button" class="btn btn-primary" id="shop_edit" style="width:99%;"
                 data-complete-text="Loading finished">确定修改
              </button>
            </form>
          </div>
       </div>
   </div>

   <script type="text/javascript">
   //ajax 修改商品
   function shop_edit(id,a,b) {
            $.ajax({
                  type: "GET",
                  url: "admin.php?k=shop_view&shopid="+id+"&r="+Math.random(),
                  dataType: "json",
				  json: "callback",
                  success: function(data){
					$('#shop_id1').val(id);
                    $('#shop_name1').val(data.name);
					$('#shop_money1').val(data.money);
					$('#shop_text1').val(data.text);
                 }
             });
   }
   $(document).ready(function(){
      $('#shop_edit').click(function()
      {
         $("#shop_edit").button('loading');
         $.post("admin.php?k=shop_edit&shopid="+$('#shop_id1').val(),
         {
          name:$('#shop_name1').val(),money:$('#shop_money1').val(),text:$('#shop_text1').val()
         },
         function(data,status){
            alert(data);
            $("#shop_edit").button('reset');
         });
     });
   });
   </script>
   <!-- end 修改商品 -->

<div class="tab-pane fade" id="shopdata_admin">
   <!-- 卡密管理 -->
        <div class="panel panel-default">
           <div class="panel-heading">卡密管理
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <!-- <input id="shopdata_word" type="text"  style="width:320px;height: 24px;border: 1px solid #CCC;" placeholder="请输入关键词">
             <a href="javascript:void(0);" onclick="document.getElementById('shopdata_word').value='';" style="margin-left:-20px;">&times;</a>
             <button id="shop_data_search" type="button" style="margin-left:20px;width:98px;background-color: #FFF;border-color: #CCC;border: 1px solid transparent;">查找</button> -->
             <a class="pull-right" href="#shopdata_add_admin" onclick="shop_list()" data-toggle="tab">添加卡密</a>
          </div>
           <table class="table table-bordered table-striped">
              <thead>
              <tr>
                <th style="text-align:center;">Id</th>
                <th style="text-align:center;">商品名称</th>
                <th style="text-align:center;">卡密</th>
                <th style="text-align:center;">添加时间</th>
                <th style="text-align:center;">操作</th>
              </tr>
              </thead>
              <tbody id="shopdata_tbody">

              </tbody>
           </table>
        </div>


   </div>
   <!-- end 卡密管理  -->


<div class="tab-pane fade" id="shopdata_add_admin">
   <!-- 添加卡密-->
      <div class="panel panel-default">
        <div class="panel-heading">批量添加卡密 <a class="pull-right" href="#shopdata_admin" onclick="shopdata_list()" data-toggle="tab">关闭</a></div>
          <div class="panle body" style="padding: 10px;">
            <p id="result" style="color:red;text-align:center;"></p><!--返回信息显示-->
            <form class="bs-example bs-example-form" role="form">
              <div class="input-group">
                 <span class="input-group-addon">商品类型：</span>
                 <select id="shopid" class="form-control">
                  <option>正在加载...</option>
                </select>
              </div>
              <br>

              <div class="form-group">
                <label for="name">卡密</label>
                <textarea id="shop_data_text" class="form-control" rows="3"></textarea>
              </div>

              <div class="input-group">
                 <span class="input-group-addon">分割符</span>
                 <input id="shop_data_exp" type="text" class="form-control" placeholder="请输入分割符">
                 <span class="input-group-addon">默认为换行符</span>
              </div>
              <br/>

                <button type="button" class="btn btn-primary" id="shop_data_add" style="width:99%;"
                 data-complete-text="Loading finished">确定添加
              </button>
            </form>
          </div>
       </div>
   </div>
   <script type="text/javascript">
   //ajax 添加卡密
   $(document).ready(function(){
      $('#shop_data_add').click(function()
      {
         $("#shop_data_add").button('loading');
         $.post("admin.php?k=shop_data_add&shopid="+$('#shopid').val(),
         {
          exp:$('#shop_data_exp').val(),text:$('#shop_data_text').val()
         },
         function(data,status){
            alert(data);
            $("#shop_data_add").button('reset');
         });
     });
   });
   </script>
   <!-- end 添加卡密 -->

   <div class="tab-pane fade" id="edit_admin_pass">
   <!-- 修改密码 -->
      <div class="panel panel-default">
        <div class="panel-heading">修改密码</div>
          <div class="panle body" style="padding: 20px;">
            <p id="result" style="color:red;text-align:center;"></p><!--返回信息显示-->
            <form class="bs-example bs-example-form" role="form">
              <div class="input-group">
                 <span class="input-group-addon">原密码</span>
                 <input id="y_pass" type="text" class="form-control" placeholder="请输入原密码">
              </div>
              <br>
              <div class="input-group">
                 <span class="input-group-addon">新密码</span>
                 <input id="n_pass" type="text" class="form-control" placeholder="请输入新密码">
              </div>
              <br/>
                <button type="button" class="btn btn-default btn-lg btn-block" id="edit_pass" 
                 data-complete-text="Loading finished">确定修改
              </button>
            </form>
          </div>
       </div>
   </div>
   <!-- end 修改密码 -->

   <div class="tab-pane fade" id="Alipay_login_form">
   <!-- 登陆支付宝 -->

   </div>
   <!-- end 登陆支付宝 -->

</div>

<script>
   $(document).ready(function(){
      //修改密码
     $('#edit_pass').click(function(){
      $("#edit_pass").button('loading');
       $.post("admin.php?k=edit_pass",
       {
         y_pass:$('#y_pass').val(),
         n_pass:$('#n_pass').val(),
       },
       function(data,status){
         $("#edit_pass").button('reset');
         $('#result').html(data);
       });
     });//修改密码
     //搜索
      $('#search').click(function(){
         $("#search").button('loading');
         $.ajax({
          type: "GET",
          url: "admin.php?k=search&p=<?php echo $p; ?>",
          data: {traing:$("#traing").val()},
          dataType: "html",
          success: function(data){
            $("#search").button('reset');
            $('#tbody').html(data);
         }
     });
   });//搜索

});

   function getState(){
      $.ajax({
          type: "GET",
          url: "admin.php?k=getState&r="+Math.random(),
          data: {},
          dataType: "html",
          success: function(data){
            $('#AlipayState').html(data);
         }
     });
  }

  function getAlipayFrom(){
      $('#Alipay_login_form').html('<div class="panel panel-default"><div class="panel-heading">登陆支付宝</div><div class="panle body" style="padding: 20px;"><div class="alert alert-warning alert-dismissable">正在加载表单,请稍后...</div></div></div>');
      $.ajax({
          type: "GET",
          url: "admin.php?k=getAlipayLoginForm&r="+Math.random(),
          data: {},
          dataType: "html",
          success: function(data){
            $('#Alipay_login_form').html('<div class="panel panel-default"><div class="panel-heading">登陆支付宝</div><div class="panle body" style="padding: 20px;">'+data+'</div></div>');
         }
     });
  }
</script>

<script type="text/javascript">
/*function change(){//点击图片刷新验证码
  document.getElementById("checkcodeImg").src = "checkCode.php?url="+checkcode_img_url+"&r="+Math.random(1);
}*/
function checksave(){//验证码验证
   if($('#checkCode').val().length==4){
      $.post("checkcode.php",
       {
         checkCode:$('#checkCode').val(),
       },
       function(data,status){
         eval('var r = '+data+';');
            if(r.checkResult=='true'){
               $('#error').html('');
               $('#Apipay_login').removeAttr("disabled"); 
            }else{
               $('#checkCode').val('');
               $('#error').html("验证码错误,请重新输入!");
               document.getElementById("checkcodeImg").src = "checkCode.php?url="+checkcode_img_url+"&r="+Math.random(1);
               $('#Apipay_login').attr("disabled","disabled");
            }
       });
   }
}   
</script>
</body>
</html>			