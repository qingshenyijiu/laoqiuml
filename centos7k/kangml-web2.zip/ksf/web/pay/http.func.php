<?php
	/*以下是Cookie合并更新函数 
	  upCookie=调用名称
	  $cookie1=原cookie
	  $cookie2=新cookie
	  
	  一个例子
	  $cookie1='key=1234;name=123'; $cookie2='key=456';
	  echo upCookie($cookie1,$cookie2);
	  合并后结果为key=456;name=123
	*/
	function upCookie($cookie1,$cookie2)
	{	
		if(strpos($cookie1,";") <0 ) $cookie1.=';';//只有一个cookie的情况
		if(strpos($cookie2,";") <0 ) $cookie2.=';';//只有一个cookie的情况
		$cookie1=explode(';',$cookie1);$cookie2=explode(';',$cookie2);
		if(empty($cookie1) || empty($cookie2)) return array();
		$array1=array();$array2=array();
		foreach($cookie1 as $val){
			$k=explode("=",$val);
			if(count($k)<2) continue;
			$array1[$k[0]]=$k[1];
		}
		foreach($cookie2 as $val){
			$k=explode("=",$val);
			if(count($k)<2) continue;
			$array2[$k[0]]=$k[1];
		}
		$Array=array_merge($array1,$array2);
		$cookie='';
		foreach($Array as $key=>$val){
			$cookie.=$key.'='.$val.';';
		}
		$cookie=rtrim($cookie,";");
		return $cookie;
	}
	/*以下是curl访问函数 
	  Http_curl=调用名称
	  $url=网址
	  $cookie=一个存放返回cookie的变量
	  $setArray=各项属性设置数组
	  $setHeader=自定义header头数组
	  $header=一个存放返回header的变量
	
		一个栗子

	    $setArray['Post']='';//post
		$setArray['Cookie']='';
		$setArray['Referer']='';//为空时来源地址为访问的url
		$setArray['UserAgent']="Mozilla/5.0 (Linux; Android 4.1.1; Nexus 7 Build/JRO03D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166  Safari/535.19";//UserAgent
		$html=Http_curl("https://www.baidu.com",$cookie,$setArray,array(),$header);//开始访问
		echo $cookie.'<hr>'.$header.'<hr>'.$html;

	*/

	function Http_curl($url,&$cookie='',$setArray=array(),$setHeader=array(),&$header='')
	{
		global $db_user,$db_pass;
		$cookie_file='./'.md5($db_user.md5($db_pass)).'.txt';
		$alipay_cookie=@file_get_contents($cookie_file);
		$setArray=array_change_key_case($setArray, CASE_LOWER);//把数组键名转为小写
		$ch=curl_init($url);//初始化
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);// https请求 不验证证书
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);// https请求 不验证hosts
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);//禁止重定向
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);//返回结果
		curl_setopt($ch, CURLOPT_HEADER,true);//获取头部才能获取cookie
		if(array_key_exists('useragent',$setArray) && $setArray['useragent']!="")//设置了User-Agent
		{
			curl_setopt($ch, CURLOPT_USERAGENT,$setArray['useragent']);
		}else{
			//默认
			curl_setopt($ch, CURLOPT_USERAGENT,"Mozilla/5.0 (Linux; Android 4.1.1; Nexus 7 Build/JRO03D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166  Safari/535.19");
		}
		
		if(array_key_exists('post',$setArray) && $setArray['post']!="")//Post
		{
				curl_setopt($ch, CURLOPT_POST,true);
				curl_setopt($ch, CURLOPT_POSTFIELDS,$setArray['post']);
		}

		if(!empty($setHeader))//自定义header
		{
			curl_setopt($ch, CURLOPT_HTTPHEADER,$setHeader);
		}
		if(array_key_exists('cookie',$setArray))//设置了Cookie
		{
			curl_setopt($ch, CURLOPT_COOKIE,$setArray['cookie']);
		}else{//没有设置则同步之前的Cookie
			curl_setopt($ch, CURLOPT_COOKIE,$alipay_cookie);
		}
	   if(array_key_exists('referer',$setArray) && $setArray['referer'] != "")//设置了Referer
	   {
	   		curl_setopt($ch, CURLOPT_REFERER, $setArray['referer']);
	   	}else
	   	{
	   		curl_setopt($ch, CURLOPT_REFERER, $url);//来源地址为访问的地址
	   	}
		//curl_setopt($ch, CURLOPT_HEADER, true);
	    $result=curl_exec($ch);

	    //echo $result;

	    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);//获取header长度
    	$header = substr($result, 0, $headerSize);//header,头部
    	//解析cookie
    	if(preg_match_all('/Set-Cookie:(.*);/iU', $header, $matches))
		{
		//有cookies返回
			foreach($matches[1] as $val){
				$cookie.=$val.';';
			}
			//自动保存Cookie
			$save_cookie=upCookie($alipay_cookie,$cookie);//Cookie合并更新
			@file_put_contents($cookie_file,$save_cookie);
		}
		$cookie=rtrim($cookie,";");//返回本次请求响应的Cookie
	    $body = substr($result, $headerSize);//body,网页内容
	    
	    if(curl_errno($ch))//有错误
		{
	    	$body=curl_error($ch);
		}
		curl_close($ch);//把它关掉，把它关掉
		return $body;//返回
	}

	/*以下是取中间文本的函数 
	  getSubstr=调用名称
	  $str=预取全文本 
	  $leftStr=左边文本
	  $rightStr=右边文本

	  一个栗子
	  echo getSubstr("<div>Hello</div>","<div>","</div>");//Hello
	*/
	function getSubstr($str, $leftStr, $rightStr)
	{
	    $left = strpos($str, $leftStr);
	    //echo '左边:'.$left;
	    $right = strpos($str, $rightStr,$left);
	    //echo '<br>右边:'.$right;
	    if($left < 0 or $right < $left) return '';
	    return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
	}
?>