<?php
require "./inc.php";
if(file_exists("lock.install")) exit("lock!");
$sql_str=<<<SQL
DROP TABLE `record`;
CREATE TABLE `record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` char(255) NOT NULL,
  `name` char(255) NOT NULL,
  `traing` char(255) NOT NULL,
  `toname` char(255) NOT NULL,
  `money` char(255) NOT NULL,
  `state` char(255) NOT NULL,
  `add_time` int(11) DEFAULT null,
  PRIMARY KEY (`id`,`traing`),
  UNIQUE KEY `traing` (`traing`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE `shop`;
CREATE TABLE `shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(255) NOT NULL,
  `money` char(255) NOT NULL,
  `text` varchar(65532) NOT NULL,
  `end_time` int(11) DEFAULT null,
  `add_time` int(11) DEFAULT null,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE `shop_data`;
CREATE TABLE `shop_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shopid` int(11) NOT NULL,
  `text` varchar(65532) NOT NULL,
  `traing` char(255) DEFAULT '0',
  `add_time` int(11) DEFAULT null,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE `buy`;
CREATE TABLE `buy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) NOT NULL,
  `token` char(255) NOT NULL,
  `name` char(255) NOT NULL,
  `money` char(255) NOT NULL,
  `traing` char(255) NOT NULL DEFAULT '0',
  `shop_data_id` int(11) NOT NULL DEFAULT 0,
  `state` int(1) NOT NULL DEFAULT 0,/*付款状态*/
  `ip` char(255) DEFAULT '0.0.0.0',
  `buy_time` int(11) DEFAULT null,
  `end_time` int(11) DEFAULT null,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;


DROP TABLE `admin`;
CREATE TABLE `admin` (
  `name` char(255) NOT NULL,
  `pass` char(255) NOT NULL,
  `token` char(255) NOT NULL,
  `end_time` int(11) DEFAULT null,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*管理员名称 admin 密码123456 */
INSERT INTO `admin` (`name`, `pass`, `token`, `end_time`) VALUES
('admin', 'e10adc3949ba59abbe56e057f20f883e', '71b7b8665277f8df6f628099b76b2967', 1443376654);

DROP TABLE `history`;
CREATE TABLE `history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` int(1) NOT NULL DEFAULT 1,
  `end_time` int(11) DEFAULT null,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SQL;

$sql=explode(";",$sql_str);
foreach($sql as $val){
	if(mysql_query($val.";")) echo 'ok!<br/>';
	else echo mysql_error().'<br/>';
}
echo file_put_contents("lock.install","ok!")?'安装成功!':'安装失败!';
?>