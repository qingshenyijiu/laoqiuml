<?php
header("Content-type: text/html; charset=utf-8");
require "./inc.php";
if(!empty($_GET['action'])){
	if(empty($_POST['name']) or empty($_POST['pass'])){
		echo '请输入用户名和密码!<br/>';
	}else{
		$name=mysql_real_escape_string($_POST['name']);
		$pass=md5($_POST['pass']);//md5加密
		$token=md5(time());
		$query=mysql_query("select * from `admin` where `name`='$name' and `pass`='$pass'");
		if(@mysql_fetch_assoc($query) and mysql_query("UPDATE `admin` SET `end_time` = '".time()."',`token`='{$token}' where `name`='$name'")){
			echo '登陆成功!';
			echo '
				<script language="javascript" type="text/javascript">
					document.cookie="token='.$token.'";
           			window.location.href="admin.php";
    			</script>
			';
		}else{
			echo '用户名或密码错误!';
		}
		
	}
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />  
   <title>登陆后台</title>
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script>
   $(document).keypress(function(e) { 
    // 回车键事件 
    if(e.which == 13) { 
   		jQuery("#login").click(); 
       } 
   }); 
	$(document).ready(function(){
	  $('#login').click(function(){
	  	$("#login").button('loading');
	    $.post("login.php?action=save",
	    {
	      name:$('#name').val(),
	      pass:$('#pass').val(),
	    },
	    function(data,status){
	      $("#login").button('reset');
	      $('#result').html(data);
	    });
	  });
	});
	</script>
</head>
<body style="width:80%;height:100%;margin:0 auto;">

<div class="" style="padding: 10px 10px 10px;margin-top:2%;">

	<div class="page-header">
   <h1>管理员登陆
   </h1>
	</div>

	<p id="result" style="color:red;text-align:center;"></p>
   <form class="bs-example bs-example-form" role="form">
      <div class="input-group">
         <span class="input-group-addon">管理员名称</span>
         <input id="name" type="text" class="form-control" placeholder="管理员名称">
      </div>
      <br>
      <div class="input-group">
         <span class="input-group-addon">管理员密码</span>
         <input id="pass" type="password" class="form-control" placeholder="管理员密码">
      </div>
	<br/>
    <button type="button" class="btn btn-primary btn-lg btn-block" id="login" 
	   data-complete-text="Loading finished">登陆后台
	</button>

   </form>
</div>

</body>
</html>