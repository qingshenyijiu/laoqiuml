<?php
	session_start();
	require "./inc.php";

	if(!empty($_GET['id']) && $_GET['id']=='shop'){

		require 'ValidateCode.class.php';  //先把类包含进来，实际路径根据实际情况进行修改。
		$_vc = new ValidateCode();		//实例化一个对象
		$_vc->doimg();		
		$_SESSION['shop_pay_session'] = $_vc->getCode();//验证码保存到SESSION中
		exit();
	}

	if(isset($_POST["check_pay_Code"])){
		$validate=$_POST["check_pay_Code"];
		$verify=empty($_SESSION["shop_pay_session"])?exit('{"ret":false,"msg":"验证码错误!"}'):$_SESSION["shop_pay_session"];
		
		if($validate!=$verify){
		//判断session值与用户输入的验证码是否一致;
		echo '{"ret":false,"msg":"验证码错误!"}'; 
		}else{
		echo '{"ret":true,"msg":"ok!"}'; 
		}
		exit();
	} 

	if(!empty($_GET['url'])){
		Header('Content-type: image/jpeg');
		echo Http_curl(urldecode($_GET['url']));
		exit();
	}

	$checkCode=empty($_POST['checkCode'])?exit('false'):$_POST['checkCode'];

	$setHeader[]='Accept-Encoding: gzip, deflate';
	$setHeader[]='X-Requested-With: XMLHttpRequest';
	$setHeader[]='Accept: text/javascript, text/html, application/xml, text/xml, */*';
	$setHeader[]='Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
	$setHeader[]='Referer: https://auth.alipay.com/login/home.htm?redirectType=parent';
	$setArray['post']="checkCode={$checkCode}&idPrefix=&timestamp=".time()."_input_charset=utf-8";

	echo http_curl("https://auth.alipay.com/login/verifyCheckCode.json",$rcookie,$setArray,$setHeader);
