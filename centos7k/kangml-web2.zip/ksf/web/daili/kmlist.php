<?php
/**
 * 卡密列表
**/
$mod='blank';
include("../api.inc.php");
$title='卡密列表';
include './header.php';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$dlrmb=$row['rmb'];
if($vip==1){
	$dljg=$rs['dl1'];
	$dljgs=$rs['dls1'];
}elseif($vip==2){
	$dljg=$rs['dl2'];
	$dljgs=$rs['dls2'];
}elseif($vip==3){
	$dljg=$rs['dl3'];
	$dljgs=$rs['dls3'];
}elseif($vip==0){
	$dljg=$rs['dl0'];
	$dljgs=$rs['dls0'];
	//exit("<script language='javascript'>window.location.href='./login.php';</script>");
}elseif($vip==4){
	$dljg=$rs['dl4'];
	$dljgs=$rs['dls4'];
}elseif($vip==5){
	$dljg=$rs['dl5'];
	$dljgs=$rs['dls5'];
}

?>
<section class="panel panel-default">
<header class="panel-heading font-bold"> 卡密管理 </header>
<div class="panel-body">
<header class="panel-heading font-bold"> 卡密价格 </header><br>
<div class="row">
  <div class="col-xs-12 col-md-2 col-sm-12">
    <button class="btn btn-success">
      代理拿货价格：<br><?php echo ''.$dljg.'元/天 + '.$dljgs.'元/GB<br>当前余额 '.$dlrmb.' 元'; ?>
    </button>
  </div>
  <?php
  $tclist=$DB->query("SELECT * FROM tc_name where `state`=1");
  $tclists=$DB->fetch($tclist);
  while($tclists){
    echo  '<div class="col-xs-12 col-md-2 col-sm-12">
      <button class="btn btn-success">
      套餐名:'.$tclists['name'].'<br>套餐ID:'.$tclists['id'].'<br>包含流量:'.($tclists['maxll']/1024/1024).'MB<br>套餐时长:'.$tclists['tcsc'].'天<br>套餐价格:'.$tclists['price'].'元
          </button>
        </div>';
  	$tclists = $DB->fetch($tclist);
  }
  ?>
</div>
<?php
function getkm($len = 18)
{
	$str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='add'){
$kind=1;

$num = round($_POST['num']);
$value = $_POST['value'];
$values=round($_POST['values'],2);
if($num<=0){exit("<script language='javascript'>alert('生成失败，卡密数量必须大于0！');history.go(-1);</script>");}
if($value<=0){exit("<script language='javascript'>alert('生成失败，生成天数必须大于0！');history.go(-1);</script>");}
if($values<=0){exit("<script language='javascript'>alert('生成失败，流量必须大于0GB！');history.go(-1);</script>");}
$rmb=$row['rmb'];
if($rmb<=0){
	exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
	}
$money = ($value*$dljg+$values*$dljgs)*$num;
$rmb=$row['rmb']-$money;
if($rmb<0){
exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
}
$sql=$DB->query("update `auth_daili` set `rmb`='$rmb' where `id`=$dlid;");

echo "<ul class='list-group'><li class='list-group-item active'>成功生成以下卡密</li>";
for ($i = 0; $i < $num; $i++) {
	$km=getkm(18);
	$sql=$DB->query("insert into `auth_kms` (`kind`,`daili`,`km`,`value`,`values`,`money`,`addtime`) values ('".$kind."','".$dlid."','".$km."','".$value."','".$values."','".$money."','".$date."')");
	if($sql) {
		echo "<li class='list-group-item'>$km</li>";
	}
}

echo '<a href="./kmlist.php" class="btn btn-default btn-block">>>返回卡密列表</a>';
include('footer.php');
exit();
}

//套餐操作开始
if($my=='addtckm'){
    $kind=1;

    $num = round($_POST['num']);

    if($num<=0){exit("<script language='javascript'>alert('生成失败，卡密数量必须大于0！');history.go(-1);</script>");}

    $rmb=$row['rmb'];
    if($rmb<=0){
        exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
    }
    $tcname = $_POST['tc'];
    $tcjg=$DB->get_row("SELECT price FROM tc_name WHERE name='$tcname'");
    $price = $num * $tcjg['price'];
    $rmb=$row['rmb']-$price;
    if($rmb<0){
        exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
    }
    $sql=$DB->query("update `auth_daili` set `rmb`='$rmb' where `id`=$dlid;");

    $tcinfo=$DB->get_row("SELECT * FROM tc_name WHERE name='$tcname'");

    echo "<ul class='list-group'><li class='list-group-item active'>成功生成以下卡密</li>";

    for ($i = 0; $i < $num; $i++) {
        $km=getkm(18);
        $sql=$DB->query("insert into `auth_kms` (`kind`,`daili`,`km`,`value`,`values`,`money`,`addtime`) values ('".$kind."','".$dlid."','".$km."','".$tcinfo['tcsc']."','".$tcinfo['maxll']."','".$tcinfo['price']."','".$date."')");
        if($sql) {
            echo "<li class='list-group-item'>$km</li>";
        }
    }

    echo '<a href="./kmlist.php" class="btn btn-default btn-block">>>返回卡密列表</a>';
	include('footer.php');
    exit();
}
//套餐操作结束

//套餐用户操作开始
if($my=='addtczh'){
    $num = round($_POST['num']);
    if($num<=0){exit("<script language='javascript'>alert('生成失败，账号数量必须大于0！');window.location.href ='kmlist.php';</script>");}
    $rmb=$row['rmb'];
    if($rmb<=0){
        exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');window.location.href ='kmlist.php';</script>");
    }
    $tcname = $_POST['tc'];
    $tcjg=$DB->get_row("SELECT price FROM tc_name WHERE name='$tcname'");
    $price = $num * $tcjg['price'];
    $rmb=$row['rmb']-$price;
    if($rmb<0){
        exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');window.location.href ='kmlist.php';</script>");
    }
    $sql=$DB->query("update `auth_daili` set `rmb`='$rmb' where `id`=$dlid;");

    $tcinfo=$DB->get_row("SELECT * FROM tc_name WHERE name='$tcname'");
    $tcid=$tcinfo['id'];
    echo "<ul class='list-group'><li class='list-group-item active'>成功生成以下账号</li>";

    for ($i = 0; $i < $num; $i++) {
        $user = time().rand();
        $pass = time().rand();
        $sql  = "insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`dlid`,`tcid`) values ('{$user}','{$pass}',0,0,'{$tcinfo['maxll']}','1','".time()."','','{$dlid}','{$tcid}')";
        $result = $DB->query($sql);
        if($sql) {
            echo "<li class='list-group-item'>账号：$user 密码：$pass 套餐ID：$tcid</li>";
        }
    }

    echo '<a href="./kmlist.php" class="btn btn-default btn-block">>>返回卡密列表</a>';
	include('footer.php');
    exit();
}
//套餐用户操作结束

elseif($my=='del'){
echo '<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title">删除卡密</h3></div>
<div class="panel-body box">';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM auth_kms WHERE id='$id'");
if($sql){echo '删除成功！';}
else{echo '删除失败！';}
echo '<hr/><a href="./kmlist.php">>>返回卡密列表</a></div></div>';
}
else
{
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$dlrmb=$row['rmb'];
echo '<form action="kmlist.php?my=add" method="POST" class="form-inline">
  <header class="font-bold"><h3 >生成卡密<h3/> </header><hr/>
  <div class="form-group">
  
    <label></label>
    <input type="text" class="form-control" name="num" placeholder="生成的个数">
  </div>
  <div class="form-group">
  <label> </label>
    <input type="text" class="form-control" name="value" placeholder="每个开通的天数">
  </div>
  <div class="form-group">
  <label> </label>
    <input type="text" class="form-control" name="values" placeholder="每个充值多少GB流量">
  </div>
   <div class="form-group">
  <label> </label>
  <input type="submit" class="form-control btn-primary" value="生成零售">
  </div>
</form><br/>
<form action="kmlist.php?my=addtckm" method="POST" class="form-inline">
  <div class="form-group">
  
    <label></label>
    <input type="text" class="form-control" name="num" placeholder="生成的个数">
  </div>
  <div class="form-group">
  <label> </label>
<select name="tc" class="form-control">';
  $tclist=$DB->query("SELECT name FROM tc_name where `state`=1");
  $tclists=$DB->fetch($tclist);
  while($tclists){
  	echo '<option value="'.$tclists['name'].'">'.$tclists['name'].' </option>';
  	$tclists=$DB->fetch($tclist);
  }
echo '</select>
  </div>
   <div class="form-group">
  <label> </label>
  <input type="submit" class="form-control btn-primary" value="生成套餐卡密">
  </div>
</form>

<form action="kmlist.php?my=addtczh" method="POST" class="form-inline">
<div class="form-group">
<label></label>
<input type="text" class="form-control" name="num" placeholder="生成的个数">
</div>
<div class="form-group">
<label> </label>
<select name="tc" class="form-control">';
  $tclist=$DB->query("SELECT name FROM tc_name where `state`=1");
  $tclists=$DB->fetch($tclist);
  while($tclists){
  	echo '<option value="'.$tclists['name'].'">'.$tclists['name'].' </option>';
  	$tclists=$DB->fetch($tclist);
  }
echo '</select>
  	    </div>

  	    <div class="form-group">
  	    <label> </label>
  	    <input type="submit" class="form-control btn-primary" value="生成套餐账号">
  	    </div>
  	    </form><br/>';

if(isset($_GET['kw'])) {
	if($_GET['type']==1) {
		$sql=" `km`='{$_GET['kw']}'";
		$numrows=$DB->count("SELECT count(*) from auth_kms WHERE{$sql}");
		$con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个卡密';
	}elseif($_GET['type']==2) {
		$sql=" `user`='{$_GET['kw']}'";
		$numrows=$DB->count("SELECT count(*) from auth_kms WHERE{$sql}");
		$con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个卡密';
	}
}else{
	$numrows=$DB->count("SELECT count(*) from auth_kms WHERE daili=$dlid");
	$sql=" 1";
	$con='共拥有 <b>'.$numrows.'</b> 个卡密';
}
echo $con;
?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>卡密</th><th>信息</th><th>状态</th><th>添加时间</th><th>使用时间</th><th>操作</th></tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM auth_kms WHERE daili=$dlid order by id desc limit $offset,$pagesize");
//$rs=$DB->query("SELECT * FROM auth_kms WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
if($res['isuse']==1) {
	$isuse='<font color="red">已使用</font><br/>使用者:'.$res['user'];
} elseif($res['isuse']==0) {
	$isuse='<font color="green">未使用</font>';
}
$res['values']=$res['values']/1024/1024 ;
echo '<tr><td><b>'.$res['km'].'</b></td><td>'.$res['value'].'天/'.$res['values'].'MB/￥'.$res['money'].'</td><td>'.$isuse.'</td><td>'.$res['addtime'].'</td><td>'.$res['usetime'].'</td><td><a href="./kmlist.php?my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a></td></tr>';
}
?>
          </tbody>
        </table>
      </div>
	  <ul class="pagination">
<?php
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="kmlist.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="kmlist.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="kmlist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="kmlist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="kmlist.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="kmlist.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>
	



</section>
<?php
include('footer.php');
?>